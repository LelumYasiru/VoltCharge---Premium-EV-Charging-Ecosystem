import React, { useState, useEffect, useRef } from 'react';
import { 
  MapPin, Battery, Heart, User, Search, Filter, Navigation, Zap, Star,
  Clock, Shield, CreditCard, Settings, ChevronRight, QrCode, ArrowLeft,
  Coffee, Wifi, TrendingUp, DollarSign, AlertTriangle, Calendar, CheckCircle,
  Mail, Lock, Phone, Sun, Home, Plus, Route, AlertOctagon, MessageSquare,
  Award, Car, Radio, BarChart2, X, Trash2, LayoutDashboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- i18n Translations ---
const translations = {
  en: {
    explore: "Explore", charging: "Charging", saved: "Saved", profile: "Profile", trip: "Trip",
    searchPlaceholder: "Search stations...", nearby: "Nearby Stations", seeAll: "See All",
    available: "Available", occupied: "Occupied", power: "Power", rate: "Rate", rating: "Rating",
    plugs: "Plugs Available", amenities: "Amenities", about: "About", navigate: "Navigate",
    startCharge: "Start Charging", reserve: "Reserve Slot", reportIssue: "Report Issue",
    scanToCharge: "Scan to Charge", manualEntry: "Start Manual Entry",
    stopSession: "Stop Session", sessions: "Sessions", points: "Points",
    vehicleDetails: "Vehicle Details", paymentMethods: "Payment Methods", history: "Charging History",
    ownerDashboard: "Host / Owner Dashboard", privacy: "Privacy & Security", settings: "App Settings",
    logout: "Log Out", wallet: "Wallet Balance", smartSuggest: "Smart Suggestion",
    suggestText: "Based on your 60kWh battery, a full charge will take ~45 mins here.",
    paymentSuccess: "Payment Successful!", invoiceReady: "Invoice ready to download.",
    login: "Login", register: "Register", email: "Email Address", password: "Password", phone: "Phone Number",
    forgotPass: "Forgot Password?", orContinueWith: "Or continue with", noAccount: "Don't have an account?",
    haveAccount: "Already have an account?", solarBadge: "100% Solar", homeHost: "Home Charger",
    registerStation: "Register New Station", powerSource: "Power Source",
    // New Features
    tripPlanner: "Trip Planner", startPoint: "Start Location", destination: "Destination",
    planRoute: "Plan Route", sos: "Emergency SOS", sosDesc: "Need help? Request a mobile charging van or tow service immediately.",
    requestHelp: "Request Help", reviews: "Reviews & Community", writeReview: "Write a Review",
    schedule: "Schedule Charge", rfid: "RFID & Cards", telematics: "Vehicle Connection",
    analytics: "Advanced Analytics", connected: "Connected", range: "Est. Range",
    greenPoints: "Green Points", redeem: "Redeem Points", dynamicPricing: "Dynamic Pricing",
    // Features 3, 4, 6, 8
    carbonSavings: "Carbon Savings", co2Saved: "CO2 Saved", treesPlanted: "Trees Equivalent",
    plugCharge: "Plug & Charge", autoDetect: "Auto-detecting Vehicle...", vehicleIdentified: "Vehicle Identified!",
    community: "Community", postStory: "Post a Story", travelogue: "Travelogue",
    myVehicles: "My Vehicles", addVehicle: "Add Vehicle", primary: "Primary"
  },
  si: {
    explore: "ගවේෂණය", charging: "චාජින්", saved: "සුරැකි", profile: "පැතිකඩ", trip: "ගමන් (Trip)",
    searchPlaceholder: "ස්ටේෂන් සොයන්න...", nearby: "ළඟම ඇති ස්ටේෂන්", seeAll: "සියල්ල",
    available: "තිබේ", occupied: "කාර්යබහුලයි", power: "ධාරිතාව", rate: "මිල", rating: "ශ්‍රේණිය",
    plugs: "ප්ලග් වර්ග", amenities: "පහසුකම්", about: "විස්තර", navigate: "යන්න (Map)",
    startCharge: "චාජ් කිරීම අරඹන්න", reserve: "වෙන් කරගන්න", reportIssue: "ගැටළුවක් වාර්තා කරන්න",
    scanToCharge: "QR කේතය ස්කෑන් කරන්න", manualEntry: "අතින් ඇතුලත් කරන්න",
    stopSession: "නතර කරන්න", sessions: "වාර ගණන", points: "ලකුණු",
    vehicleDetails: "වාහනයේ විස්තර", paymentMethods: "ගෙවීම් ක්‍රම", history: "ඉතිහාසය",
    ownerDashboard: "ඔබගේ ස්ටේෂන් (Host)", privacy: "ආරක්ෂාව", settings: "සැකසුම්",
    logout: "ඉවත් වන්න", wallet: "පෙරගෙවුම් ශේෂය", smartSuggest: "ස්මාර්ට් යෝජනාව",
    suggestText: "ඔබගේ 60kWh බැටරිය පිරවීමට විනාඩි 45ක් පමණ ගත වේ.",
    paymentSuccess: "ගෙවීම සාර්ථකයි!", invoiceReady: "බිල්පත ලබාගත හැක.",
    login: "පිවිසෙන්න", register: "ලියාපදිංචි වන්න", email: "ඊමේල් ලිපිනය", password: "මුරපදය", phone: "දුරකථන අංකය",
    forgotPass: "මුරපදය අමතකද?", orContinueWith: "නැතහොත් මින් පිවිසෙන්න", noAccount: "ගිණුමක් නැද්ද?",
    haveAccount: "දැනටමත් ගිණුමක් තිබේද?", solarBadge: "සූර්ය බලශක්තිය (Solar)", homeHost: "නිවසේ චාජරය",
    registerStation: "නව ස්ටේෂන් එකක් ලියාපදිංචි කරන්න", powerSource: "බලශක්ති ප්‍රභවය",
    // New Features
    tripPlanner: "ගමන් සැලසුම", startPoint: "ආරම්භක ස්ථානය", destination: "ගමනාන්තය",
    planRoute: "මාර්ගය සකසන්න", sos: "හදිසි අවස්ථා (SOS)", sosDesc: "උදව් අවශ්‍යද? Mobile charging රථයක් හෝ Towing සේවාවක් ගෙන්වන්න.",
    requestHelp: "උදව් ඉල්ලන්න", reviews: "ප්‍රතිචාර (Reviews)", writeReview: "ප්‍රතිචාරයක් එක් කරන්න",
    schedule: "වෙලාවක් වෙන් කරන්න", rfid: "RFID සහ කාඩ්පත්", telematics: "වාහනයේ තොරතුරු",
    analytics: "විශ්ලේෂණ (Analytics)", connected: "සම්බන්ධ කර ඇත", range: "ඉතිරි දුර",
    greenPoints: "හරිත ලකුණු", redeem: "ලකුණු භාවිතා කරන්න", dynamicPricing: "මිල වෙනස් කිරීම්",
    // Features 3, 4, 6, 8
    carbonSavings: "කාබන් ඉතිරිය", co2Saved: "CO2 ඉතිරි කළ ප්‍රමාණය", treesPlanted: "සමාන වන ගස් ගණන",
    plugCharge: "Plug & Charge", autoDetect: "වාහනය හඳුනාගනිමින්...", vehicleIdentified: "වාහනය හඳුනාගත්තා!",
    community: "ප්‍රජාව", postStory: "අත්දැකීමක් බෙදාගන්න", travelogue: "සංචාරක සටහන්",
    myVehicles: "මගේ වාහන", addVehicle: "වාහනයක් එක් කරන්න", primary: "ප්‍රධාන"
  }
};

// --- Mock Data ---
const MOCK_STATIONS = [
  {
    id: 1, name: "Colombo Central Power", address: "York Street, Colombo 01",
    status: "available", plugs: ["CCS", "CHAdeMO"], power: "150kW",
    price: 85, distance: "0.8 km", rating: 4.8, reviews: 124, type: "commercial",
    image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400",
    amenities: ["Cafe", "Wifi", "Restroom"], hours: "24/7",
    description: "Ultra-fast charging station located in the heart of Colombo. Ideal for a quick top-up while shopping or at work.",
    reviewsList: [
      { user: "Kamal P.", rating: 5, text: "Great charger! Very fast and the cafe nearby is awesome." },
      { user: "Nimal D.", rating: 4, text: "Good speed but a bit crowded during weekends." }
    ]
  },
  {
    id: 2, name: "Kandy Express Hub", address: "Peradeniya Rd, Kandy",
    status: "occupied", plugs: ["Type 2", "CCS"], power: "50kW",
    price: 65, distance: "3.2 km", rating: 4.5, reviews: 89, type: "commercial",
    image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400",
    amenities: ["Wifi", "Restroom"], hours: "6:00 AM - 10:00 PM",
    description: "Reliable charging hub near Kandy city center. Features standard fast charging for daily commuters.",
    reviewsList: [
      { user: "Sunil W.", rating: 4, text: "Convenient location but sometimes the Type 2 plug has issues." }
    ]
  },
  {
    id: 4, name: "Saman's Solar Home", address: "Malabe Road, Thalahena",
    status: "available", plugs: ["Type 2"], power: "7kW",
    price: 45, distance: "2.1 km", rating: 5.0, reviews: 12, type: "home_solar",
    image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400",
    amenities: ["Wifi"], hours: "8:00 AM - 6:00 PM",
    description: "100% Solar powered home charger. Relax in my garden while your car charges!",
    reviewsList: [
      { user: "Piyal M.", rating: 5, text: "Amazing host! Offered me a tea while waiting. Highly recommended for solar lovers." },
      { user: "Asanka S.", rating: 5, text: "Very cheap and eco-friendly." }
    ]
  },
  {
    id: 3, name: "Galle Fort Charging", address: "Lighthouse St, Galle",
    status: "available", plugs: ["CCS"], power: "100kW",
    price: 75, distance: "1.5 km", rating: 4.9, reviews: 56, type: "commercial",
    image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400",
    amenities: ["Cafe", "Restroom"], hours: "24/7",
    description: "Beautifully located charging point inside Galle Fort. Perfect for tourists and local residents.",
    reviewsList: []
  },
  { id: 5, name: "Kurunegala Fast Charge", address: "Dambulla Rd, Kurunegala", status: "available", plugs: ["CCS", "Type 2"], power: "120kW", price: 80, distance: "45 km", rating: 4.7, reviews: 34, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi", "Restroom", "Cafe"], hours: "24/7", description: "Convenient stop heading North.", reviewsList: [] },
  { id: 6, name: "Nuwara Eliya Eco Station", address: "Lake Gregory, Nuwara Eliya", status: "available", plugs: ["CCS", "CHAdeMO"], power: "50kW", price: 70, distance: "150 km", rating: 4.9, reviews: 88, type: "commercial", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe", "Park"], hours: "6:00 AM - 8:00 PM", description: "Enjoy the cold breeze while your car charges.", reviewsList: [] },
  { id: 7, name: "Kamal's Home Setup", address: "Maharagama, Colombo", status: "occupied", plugs: ["Type 2"], power: "7kW", price: 40, distance: "12 km", rating: 4.6, reviews: 8, type: "home_solar", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi"], hours: "9:00 AM - 5:00 PM", description: "Cheap home solar charging.", reviewsList: [] },
  { id: 8, name: "Negombo Beach Chargers", address: "Porutota Rd, Negombo", status: "available", plugs: ["CCS"], power: "150kW", price: 85, distance: "35 km", rating: 4.8, reviews: 45, type: "commercial", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi", "Cafe", "Beach Access"], hours: "24/7", description: "Super fast charging by the beach.", reviewsList: [] },
  { id: 9, name: "Anuradhapura Heritage Hub", address: "Puttalam Rd, Anuradhapura", status: "available", plugs: ["Type 2", "CCS"], power: "50kW", price: 65, distance: "200 km", rating: 4.5, reviews: 22, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Restroom"], hours: "24/7", description: "Essential charging point in the dry zone.", reviewsList: [] },
  { id: 10, name: "Jaffna Solar Grid", address: "Hospital Rd, Jaffna", status: "available", plugs: ["CCS", "CHAdeMO"], power: "100kW", price: 75, distance: "390 km", rating: 4.9, reviews: 15, type: "commercial", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe", "Wifi"], hours: "24/7", description: "Solar powered supercharger in the north.", reviewsList: [] },
  { id: 11, name: "Sunil's Garage", address: "Gampaha", status: "available", plugs: ["Type 2"], power: "3kW", price: 35, distance: "28 km", rating: 4.2, reviews: 5, type: "home_solar", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: [], hours: "6:00 AM - 10:00 PM", description: "Standard plug at my garage.", reviewsList: [] },
  { id: 12, name: "Matara Highway Hub", address: "Matara Interchange", status: "occupied", plugs: ["CCS"], power: "150kW", price: 90, distance: "160 km", rating: 4.8, reviews: 110, type: "commercial", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", amenities: ["Restroom", "Cafe", "Wifi"], hours: "24/7", description: "Fast charger right off the highway exit.", reviewsList: [] },
  { id: 13, name: "Trinco Blue Charge", address: "Uppuveli, Trincomalee", status: "available", plugs: ["Type 2", "CCS"], power: "50kW", price: 70, distance: "260 km", rating: 4.6, reviews: 28, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Beach Access", "Cafe"], hours: "24/7", description: "Charge while you enjoy the eastern beaches.", reviewsList: [] },
  { id: 14, name: "Batticaloa City Points", address: "Main St, Batticaloa", status: "available", plugs: ["Type 2"], power: "22kW", price: 50, distance: "310 km", rating: 4.3, reviews: 12, type: "commercial", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Restroom"], hours: "8:00 AM - 8:00 PM", description: "City center AC charging.", reviewsList: [] },
  { id: 15, name: "Rathnapura Gem City Charge", address: "Main Road, Rathnapura", status: "occupied", plugs: ["CCS", "Type 2"], power: "50kW", price: 65, distance: "100 km", rating: 4.5, reviews: 41, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi"], hours: "24/7", description: "Reliable charging on the way to Sri Pada.", reviewsList: [] },
  { id: 16, name: "Nimal's Eco Charge", address: "Panadura", status: "available", plugs: ["Type 2"], power: "7kW", price: 40, distance: "25 km", rating: 4.9, reviews: 18, type: "home_solar", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi"], hours: "8:00 AM - 5:00 PM", description: "Solar powered EV charging in Panadura.", reviewsList: [] },
  { id: 17, name: "Hikkaduwa Surf & Charge", address: "Galle Rd, Hikkaduwa", status: "available", plugs: ["CCS"], power: "100kW", price: 80, distance: "95 km", rating: 4.7, reviews: 63, type: "commercial", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe", "Beach Access"], hours: "24/7", description: "Quick charge before you hit the waves.", reviewsList: [] },
  { id: 18, name: "Kataragama Pilgrimage Stop", address: "Kataragama City", status: "available", plugs: ["Type 2", "CCS"], power: "50kW", price: 60, distance: "280 km", rating: 4.6, reviews: 52, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Restroom", "Cafe"], hours: "24/7", description: "Charge your EV while visiting the sacred city.", reviewsList: [] },
  { id: 19, name: "Dambulla Cave Charge", address: "A9 Road, Dambulla", status: "occupied", plugs: ["CCS", "CHAdeMO"], power: "150kW", price: 85, distance: "150 km", rating: 4.8, reviews: 75, type: "commercial", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi", "Restroom"], hours: "24/7", description: "Superfast charging next to Dambulla Cave Temple.", reviewsList: [] },
  { id: 20, name: "Avissawella Transit", address: "Colombo Rd, Avissawella", status: "available", plugs: ["Type 2"], power: "22kW", price: 55, distance: "60 km", rating: 4.3, reviews: 19, type: "commercial", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe"], hours: "6:00 AM - 10:00 PM", description: "AC charging point in Avissawella town.", reviewsList: [] },
  { id: 21, name: "Priyanka's Driveway", address: "Homagama", status: "available", plugs: ["Type 2"], power: "11kW", price: 45, distance: "20 km", rating: 4.7, reviews: 14, type: "home_solar", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", amenities: ["Wifi"], hours: "7:00 AM - 7:00 PM", description: "Safe driveway charging in Homagama.", reviewsList: [] },
  { id: 22, name: "Ella Mountain Charge", address: "Wellawaya Rd, Ella", status: "available", plugs: ["CCS"], power: "50kW", price: 75, distance: "200 km", rating: 4.9, reviews: 94, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe", "Wifi", "Restroom"], hours: "24/7", description: "Scenic charging spot with a great cafe.", reviewsList: [] },
  { id: 23, name: "Vavuniya Gateway", address: "Kandy Rd, Vavuniya", status: "occupied", plugs: ["CCS"], power: "100kW", price: 80, distance: "250 km", rating: 4.5, reviews: 33, type: "commercial", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", amenities: ["Restroom"], hours: "24/7", description: "Essential charge before heading to the deep north.", reviewsList: [] },
  { id: 24, name: "Polonnaruwa Ancient Charge", address: "New Town, Polonnaruwa", status: "available", plugs: ["Type 2", "CCS"], power: "50kW", price: 65, distance: "220 km", rating: 4.6, reviews: 27, type: "commercial", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", amenities: ["Cafe"], hours: "6:00 AM - 10:00 PM", description: "Convenient charging while exploring the ruins.", reviewsList: [] }
];

const MOCK_VE_ADMIN_SAFE = [
  { id: 1, name: 'MG ZS EV', type: 'Car', battery: '44.5 kWh', range: '263 km', soc: 65, image: 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=200' }
];
const MOCK_VEHICLES = []; // Default empty

const MOCK_COMMUNITY = [
  { id: 1, user: "Amila Perera", title: "Scenic Drive to Nuwara Eliya", content: "Charged my Model 3 at the Ella Mountain station. The view was breathtaking! #EVLife #Ella", image: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&q=80&w=400", likes: 45, comments: 12 },
  { id: 2, user: "Dilini Silva", title: "First Solar Charge!", content: "Tried out Saman's Solar Home charger in Malabe. Super friendly host and very cheap!", image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?auto=format&fit=crop&q=80&w=400", likes: 89, comments: 24 },
  { id: 3, user: "Kasun Jayawardena", title: "Trip to Jaffna", content: "Long journey but the charging network is improving. Jaffna Solar Grid is top notch.", image: "https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?auto=format&fit=crop&q=80&w=400", likes: 32, comments: 5 },
  { id: 4, user: "Nuwan H.", title: "Colombo to Galle", content: "Expressway charging is so easy now. Matara Highway Hub is super fast!", likes: 56, comments: 8 },
  { id: 5, user: "Piumi K.", title: "Nissan Leaf Tips", content: "Battery management is key for long trips. Use B-mode in traffic!", likes: 72, comments: 15 },
  { id: 6, user: "Sahan R.", title: "Ather 450X Performance", content: "Zip mode in Colombo traffic is a game changer. #ElectricScooter", likes: 120, comments: 40 },
  { id: 7, user: "Janaki S.", title: "Home Solar Success", content: "Generated 15 units today and charged my car for free! #SolarSriLanka", likes: 230, comments: 55 },
  { id: 8, user: "Ruwan W.", title: "Kandy Hill Climb", content: "Tesla's torque is insane on the Kadugannawa climb. No sweat.", likes: 95, comments: 22 },
  { id: 9, user: "Tharindu M.", title: "Negombo Chargers", content: "Beach access while charging? Yes please! Negombo Beach Chargers rocks.", likes: 44, comments: 6 },
  { id: 10, user: "Ishani F.", title: "MG ZS EV Review", content: "Best value for money EV in SL currently. Loving the range.", likes: 110, comments: 18 },
  { id: 11, user: "Malith G.", title: "Battery Health", content: "80,000 km and still at 92% SOH. Slow charging is the secret.", likes: 88, comments: 30 },
  { id: 12, user: "Chathura B.", title: "Roadside SOS Experience", content: "Mobile van came in 15 mins. Amazing service by VoltCharge!", likes: 340, comments: 120 },
  { id: 13, user: "Gayani P.", title: "Charging Etiquette", content: "Please move your car once charging is done. Don't block slots!", likes: 500, comments: 95 },
  { id: 14, user: "Roshan A.", title: "Future is Electric", content: "Can't wait for more ultra-fast chargers in the North and East.", likes: 150, comments: 45 },
  { id: 15, user: "Vimukthi S.", title: "Weekend Getaway", content: "Hikkaduwa trip was seamless. Chargers everywhere now.", likes: 67, comments: 11 },
  { id: 16, user: "Suresh P.", title: "Katunayake Fast Charge", content: "Just 30 mins for a full charge at the airport. Ready for the trip!", likes: 45, comments: 3 },
  { id: 17, user: "Deepika R.", title: "Eco-friendly Driving", content: "Saved 50kg of CO2 this month alone. Feeling great! 🌱", likes: 210, comments: 12 },
  { id: 18, user: "Nalin K.", title: "Morning Rush at Colombo", content: "City chargers are busy. Better book in advance via VoltCharge.", likes: 30, comments: 15 },
  { id: 19, user: "Anjali M.", title: "Night Charging Tips", content: "Rates are cheaper after 10 PM. Save money while you sleep!", likes: 180, comments: 22 },
  { id: 20, user: "Pradeep G.", title: "Mountain Climbing with EV", content: "Rathnapura to Adam's Peak was smooth. regenerative braking saved me 5% battery on the way down!", likes: 95, comments: 8 },
  { id: 21, user: "Sewwandi W.", title: "New Charger in Mirissa", content: "Found a hidden gem near the coast. 22kW AC charger working perfectly.", likes: 120, comments: 14 },
  { id: 22, user: "Dinesh L.", title: "Software Update Today", content: "Tesla update improved my range by 10km. Amazing how these cars get better over time.", likes: 300, comments: 55 },
  { id: 23, user: "Sandun H.", title: "EV Meetup in Kandy", content: "Great meeting fellow EV owners today. Let's grow this community!", likes: 250, comments: 40 },
  { id: 24, user: "Kavindi F.", title: "Longest Trip Ever", content: "Colombo to Batticaloa and back. No range anxiety thanks to this app.", likes: 420, comments: 88 },
  { id: 25, user: "Lahiru S.", title: "Battery Pre-conditioning", content: "Always pre-condition your battery in cold mornings for better efficiency.", likes: 65, comments: 10 },
  { id: 26, user: "Madushani T.", title: "Solar Power rocks", content: "Full charge from my home panels. Driving on sunshine! ☀️", likes: 540, comments: 110 },
  { id: 27, user: "Asanka N.", title: "Maintenance Cost", content: "Two years of driving and zero maintenance costs so far. Unbeatable.", likes: 190, comments: 35 },
  { id: 28, user: "Pavani D.", title: "Kid-friendly Stations", content: "Matara Highway station has a great kids area. Made our trip so much easier.", likes: 130, comments: 20 },
  { id: 29, user: "Harsha J.", title: "Charging at Work", content: "Company just installed 5 chargers. No more charging worries!", likes: 310, comments: 15 },
  { id: 30, user: "Umesh K.", title: "Emergency SOS", content: "Used the SOS button today. Very professional team. Highly recommend.", likes: 600, comments: 150 },
  { id: 31, user: "Inoka G.", title: "EV Bike Review", content: "Super Soco is the best for city commuting. Extremely cheap to run.", likes: 85, comments: 12 },
  { id: 32, user: "Rajeewa W.", title: "Jaffna Solar Grid", content: "Clean energy for a clean city. Best charger in the north.", likes: 145, comments: 9 },
  { id: 33, user: "Manoj P.", title: "Range vs Speed", content: "Keeping it at 80km/h on the highway gives the best range results.", likes: 220, comments: 44 },
  { id: 34, user: "Shanika S.", title: "Beautiful Bentota", content: "Quick charge and a walk on the beach. Perfection.", likes: 175, comments: 18 },
  { id: 35, user: "Wasantha L.", title: "Heavy Rain Charging", content: "Charged in a storm today. Waterproofing works as promised. No issues.", likes: 90, comments: 25 }
];

const MOCK_VEHICLES_DB = [
  { id: 1, name: "Tesla Model 3", type: "Car", battery: "75 kWh", range: "450 km" },
  { id: 2, name: "Nissan Leaf", type: "Car", battery: "40 kWh", range: "270 km" },
  { id: 3, name: "MG ZS EV", type: "Car", battery: "44.5 kWh", range: "263 km" },
  { id: 4, name: "Hyundai Kona Electric", type: "Car", battery: "64 kWh", range: "484 km" },
  { id: 5, name: "Ather 450X", type: "Scooter", battery: "3.7 kWh", range: "146 km" },
  { id: 6, name: "BMW i3", type: "Car", battery: "42.2 kWh", range: "310 km" },
  { id: 7, name: "Audi e-tron", type: "Car", battery: "95 kWh", range: "436 km" },
  { id: 8, name: "Jaguar I-PACE", type: "Car", battery: "90 kWh", range: "470 km" },
  { id: 9, name: "Kia Niro EV", type: "Car", battery: "64 kWh", range: "455 km" },
  { id: 10, name: "Porsche Taycan", type: "Car", battery: "93.4 kWh", range: "412 km" },
  { id: 11, name: "Renault Zoe", type: "Car", battery: "52 kWh", range: "395 km" },
  { id: 12, name: "Mini Cooper SE", type: "Car", battery: "32.6 kWh", range: "235 km" },
  { id: 13, name: "Fiat 500e", type: "Car", battery: "42 kWh", range: "320 km" },
  { id: 14, name: "Polestar 2", type: "Car", battery: "78 kWh", range: "480 km" },
  { id: 15, name: "Volvo XC40 Recharge", type: "Car", battery: "78 kWh", range: "418 km" },
  { id: 16, name: "Ford Mustang Mach-E", type: "Car", battery: "88 kWh", range: "440 km" },
  { id: 17, name: "Volkswagen ID.4", type: "Car", battery: "77 kWh", range: "522 km" },
  { id: 18, name: "BYD Atto 3", type: "Car", battery: "60.48 kWh", range: "420 km" },
  { id: 19, name: "MG 4 EV", type: "Car", battery: "64 kWh", range: "450 km" },
  { id: 20, name: "Ora Good Cat", type: "Car", battery: "63 kWh", range: "500 km" },
  { id: 21, name: "TVS iQube", type: "Scooter", battery: "3.04 kWh", range: "100 km" },
  { id: 22, name: "Ola S1 Pro", type: "Scooter", battery: "4 kWh", range: "181 km" },
  { id: 23, name: "Bajaj Chetak", type: "Scooter", battery: "3 kWh", range: "90 km" },
  { id: 24, name: "Super Soco TC Max", type: "Bike", battery: "3.24 kWh", range: "110 km" },
  { id: 25, name: "Zero SR/F", type: "Bike", battery: "14.4 kWh", range: "259 km" },
  { id: 26, name: "Harley-Davidson LiveWire", type: "Bike", battery: "15.5 kWh", range: "235 km" },
  { id: 27, name: "Lucid Air", type: "Car", battery: "112 kWh", range: "837 km" },
  { id: 28, name: "Rivian R1T", type: "Truck", battery: "135 kWh", range: "505 km" },
  { id: 29, name: "GMC Hummer EV", type: "Truck", battery: "212 kWh", range: "530 km" },
  { id: 31, name: "Sur-Ron Light Bee X", type: "Bike", battery: "1.9 kWh", range: "100 km" },
  { id: 32, name: "Super Soco TS Street Hunter", type: "Bike", battery: "1.92 kWh", range: "60 km" },
  { id: 33, name: "Zero DS", type: "Bike", battery: "7.2 kWh", range: "132 km" },
  { id: 34, name: "Energica Ego", type: "Bike", battery: "21.5 kWh", range: "400 km" },
  { id: 35, name: "Cake Kalk OR", type: "Bike", battery: "2.6 kWh", range: "80 km" },
  { id: 36, name: "Evoke Urban Classic", type: "Bike", battery: "10.04 kWh", range: "200 km" },
  { id: 37, name: "Damon Hypersport", type: "Bike", battery: "20 kWh", range: "320 km" },
  { id: 38, name: "Lightning LS-218", type: "Bike", battery: "12 kWh", range: "160 km" },
  { id: 39, name: "Triumph TE-1", type: "Bike", battery: "15 kWh", range: "161 km" },
  { id: 40, name: "Verge TS", type: "Bike", battery: "20.2 kWh", range: "300 km" }
];


const SRI_LANKA_CITIES = [
  "Colombo", "Kandy", "Galle", "Jaffna", "Negombo", "Anuradhapura", "Trincomalee", "Batticaloa", "Matara", "Kurunegala",
  "Ratnapura", "Badulla", "Nuwara Eliya", "Kalutara", "Gampaha", "Dambulla", "Sigiriya", "Ella", "Hambantota", "Vavuniya",
  "Mannar", "Mullaitivu", "Kilinochchi", "Polonnaruwa", "Ampara", "Puttalam", "Chilaw", "Kegalle", "Monaragala", "Bandarawela",
  "Haputale", "Beruwala", "Hikkaduwa", "Bentota", "Tangalle", "Tissamaharama", "Kataragama", "Arugam Bay", "Pasikuda", "Kalmunai",
  "Homagama", "Kottawa", "Maharagama", "Nugegoda", "Dehiwala", "Mount Lavinia", "Moratuwa", "Panadura", "Aluthgama", "Ambalangoda",
  "Weligama", "Mirissa", "Dickwella", "Wellawaya", "Passara", "Mahiyanganaya", "Bibile", "Kalkudah", "Chenkalady", "Valaichchenai",
  "Akkaraipattu", "Pottuvil", "Panama", "Nilaveli", "Kuchchaveli", "Elephant Pass", "Chavakachcheri", "Point Pedro", "Kankesanthurai", "Kayts",
  "Madhu", "Medawachchiya", "Mihintale", "Kekirawa", "Habarana", "Kaduruwela", "Minneriya", "Naula", "Matale", "Peradeniya",
  "Katugastota", "Gampola", "Nawalapitiya", "Hatton", "Talawakele", "Nanu Oya", "Welimada", "Keppetipola", "Balangoda", "Pelmadulla",
  "Kuruwita", "Avissawella", "Kosgama", "Hanwella", "Padukka", "Horana", "Ingiriya", "Bulathsinhala", "Mathugama", "Agalawatta",
  "Elpitiya", "Karapitiya", "Unawatuna", "Koggala", "Ahangama", "Midigama", "Deniyaya", "Akuressa", "Hakmana", "Kamburupitiya",
  "Beliatta", "Weeraketiya", "Embilipitiya", "Udawalawe", "Middeniya", "Angunukolapelessa", "Ambalantota", "Lunugamvehera", "Buttala", "Siyambalanduwa",
  "Uhana", "Damana", "Maha Oya", "Padiyathalawa", "Dehiattakandiya", "Aranthalawa", "Eravur", "Kattankudy", "Oddamavadi", "Vakarai",
  "Mutur", "Kinniya", "Kantale", "Serunuwara", "Padaviya", "Kebithigollewa", "Horowupotana", "Kahatagasdigiliya", "Rambewa", "Galenbindunuwewa",
  "Talawa", "Thambuthegama", "Galnewa", "Eppawala", "Nochchiyagama", "Anamaduwa", "Galgamuwa", "Nikaweratiya", "Wariyapola", "Hettipola",
  "Kuliyapitiya", "Pannala", "Giriulla", "Narammala", "Alawwa", "Polgahawela", "Mawathagama", "Rideegama", "Ibbagamuwa", "Melsiripura",
  "Galewela", "Pallepola", "Yatawatta", "Rattota", "Ukuwela", "Wattegama", "Kundasale", "Digana", "Teldeniya", "Rangala",
  "Hasalaka", "Girandurukotte", "Kandaketiya", "Meegahakiula", "Lunugala", "Namunukula", "Demodara", "Hali-Ela", "Kandapola", "Ragala",
  "Walapane", "Rikillagaskada", "Hanguranketha", "Padiyapelella", "Ginigathena", "Laxapana", "Maskeliya", "Bogawantalawa", "Agarapatana", "Kotagala",
  "Pundaluoya", "Ramboda", "Pussellawa", "Gelioya", "Kadugannawa", "Pilimathalawa", "Menikhinna", "Madawala", "Kengalla", "Rajawella",
  "Medamahanuwara", "Hunnasgiriya", "Ududumbara", "Meemure", "Laggala", "Pallegama", "Illukkumbura", "Bakamuna", "Elkaduwa", "Panwila",
  "Madulkelle", "Alawathugoda", "Akurana", "Poojapitiya", "Hedeniya", "Galagedara", "Hatharaliyadda", "Rambukkana", "Mawanella", "Hemmathagama",
  "Aranayaka", "Galigamuwa", "Warakapola", "Ambepussa", "Mirigama", "Veyangoda", "Nittambuwa", "Pasyala", "Yakkala", "Ganemulla",
  "Ragama", "Kandana", "Ja-Ela", "Seeduwa", "Katunayake", "Kochchikade", "Wennappuwa", "Marawila", "Madampe", "Mundel",
  "Vanathavilluwa", "Karuwalagaswewa", "Nawagattegama", "Pallama", "Kobeigane", "Mahawa", "Ambanpola", "Omanthai", "Mankulam", "Paranthan",
  "Iyakachchi", "Pallai", "Kodikamam", "Navatkuli", "Nallur", "Kokuvil", "Kondavil", "Chunnakam", "Mallakam", "Tellippalai",
  "Valvettithurai", "Karainagar", "Delft", "Velanai", "Pungudutivu", "Nainativu", "Ja-Ela", "Ekala", "Kadawatha", "Kiribathgoda", "Kelaniya", "Wattala"
];

// --- Sub-Components ---
const StationCard = ({ station, onClick, t, isFavorite, toggleFav }) => (
  <motion.div whileTap={{ scale: 0.98 }} className="card" style={styles.stationCard} onClick={onClick}>
    <div style={styles.cardImageContainer}>
      <img src={station.image} alt={station.name} style={styles.cardImage} />
      <div style={{...styles.statusBadge, backgroundColor: station.status === 'available' ? 'var(--success)' : 'var(--error)'}}>
        {station.status === 'available' ? t.available : t.occupied}
      </div>
      {station.type === 'home_solar' && (
        <div style={{...styles.statusBadge, top: 'auto', bottom: '12px', right: '12px', backgroundColor: '#eab308', display: 'flex', gap: '4px', alignItems: 'center'}}>
          <Sun size={12} color="black"/> <span style={{color: 'black'}}>{t.solarBadge}</span>
        </div>
      )}
      <button style={styles.favBtnFloating} onClick={(e) => { e.stopPropagation(); toggleFav(station.id); }}>
        <Heart size={16} fill={isFavorite ? "var(--error)" : "none"} color={isFavorite ? "var(--error)" : "white"} />
      </button>
    </div>
    <div style={styles.cardInfo}>
      <div style={styles.cardHeader}>
        <h3 style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          {station.type === 'home_solar' && <Home size={16} color="var(--primary)" />}
          {station.name}
        </h3>
        <div style={styles.ratingBadge}>
          <Star size={14} fill="gold" color="gold" /><span>{station.rating}</span>
        </div>
      </div>
      <p style={styles.cardAddress}>{station.address}</p>
      <div style={styles.cardFooter}>
        <div style={styles.plugInfo}>
          <Zap size={14} color="var(--primary)" /><span>{station.power} • {station.plugs.join(', ')}</span>
        </div>
        <div style={styles.priceInfo}>
          <span>{station.distance}</span><span style={styles.dot}>•</span>
          <span style={styles.priceText}>Rs.{station.price}/kWh</span>
        </div>
      </div>
    </div>
  </motion.div>
);

const Modal = ({ isOpen, onClose, children }) => (
  <AnimatePresence>
    {isOpen && (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={styles.modalOverlay} onClick={onClose}>
        <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 25 }} style={styles.modalContent} onClick={e => e.stopPropagation()}>
          <div style={styles.modalHandle} />
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);

// --- Screens ---

const AuthScreen = ({ t, onLogin, lang, setLang }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState(''); // NEW
  const [phoneNumber, setPhoneNumber] = useState(''); // NEW
  const [error, setError] = useState('');
  const [role, setRole] = useState('driver'); // 'driver' or 'host'
  const [stationName, setStationName] = useState('');
  const [address, setAddress] = useState('');

  const handleAuth = () => {
    setError('');
    if (!email || !password || (!isLogin && (!fullName || !phoneNumber)) || (!isLogin && role === 'host' && (!stationName || !address))) {
      setError(lang === 'si' ? 'කරුණාකර සියලු විස්තර පුරවන්න!' : 'Please fill all required fields!');
      return;
    }

    const users = JSON.parse(localStorage.getItem('voltcharge_users') || '{}');

    if (isLogin) {
      if (email === 'admin@gmail.com' && password === '1234') {
        onLogin(email, { name: 'Super Admin', role: 'admin' });
        return;
      }
      if (users[email] && users[email].password === password) {
        onLogin(email, users[email]);
      } else {
        setError(lang === 'si' ? 'ඊමේල් හෝ මුරපදය වැරදියි!' : 'Invalid email or password!');
      }
    } else {
      if (users[email]) {
        setError(lang === 'si' ? 'මෙම ඊමේල් ලිපිනය දැනටමත් ලියාපදිංචි කර ඇත!' : 'This email is already registered!');
      } else {
        const userData = { name: fullName, password, role, phone: phoneNumber, stationName, address };
        users[email] = userData;
        localStorage.setItem('voltcharge_users', JSON.stringify(users));
        onLogin(email, userData);
      }
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={styles.authContainer}>
      <div style={{ position: 'absolute', top: '20px', right: '20px', zIndex: 10 }}>
        <select value={lang} onChange={(e) => setLang(e.target.value)} style={{ background: 'rgba(0,0,0,0.5)', color: 'white', border: '1px solid var(--glass-border)', padding: '6px 12px', borderRadius: '12px', outline: 'none', cursor: 'pointer' }}>
          <option value="en">EN</option>
          <option value="si">සිං</option>
        </select>
      </div>
      <div style={styles.authHero}>
        <div style={styles.authLogoBox}>
          <img src="logo.png" alt="VoltCharge Logo" style={{ width: '80px', height: '80px', objectFit: 'contain' }} />
        </div>
        <h1 style={{ color: 'white', fontSize: '32px', marginTop: '16px' }}>VoltCharge</h1>
        <p style={{ color: 'rgba(255,255,255,0.7)' }}>Your Premium EV Ecosystem</p>
      </div>

      <div style={styles.authFormContainer}>
        <div style={styles.authTabs}>
          <button style={{...styles.authTabBtn, color: isLogin ? 'var(--primary)' : 'var(--text-muted)', borderBottom: isLogin ? '2px solid var(--primary)' : '2px solid transparent'}} onClick={() => setIsLogin(true)}>{t.login}</button>
          <button style={{...styles.authTabBtn, color: !isLogin ? 'var(--primary)' : 'var(--text-muted)', borderBottom: !isLogin ? '2px solid var(--primary)' : '2px solid transparent'}} onClick={() => setIsLogin(false)}>{t.register}</button>
        </div>

        <div style={{ marginTop: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {error && <div style={{ padding: '12px', background: 'rgba(255, 77, 77, 0.1)', border: '1px solid var(--error)', borderRadius: '8px', color: 'var(--error)', fontSize: '12px', textAlign: 'center' }}>{error}</div>}
          
          {!isLogin && (
            <div style={{marginBottom: '8px'}}>
              <p style={{fontSize:'12px', color:'var(--text-muted)', marginBottom:'8px'}}>I am a:</p>
              <div style={{...styles.filterChips, gap: '8px'}}>
                <span style={role === 'driver' ? styles.chipActive : styles.chip} onClick={() => setRole('driver')}>🚗 {lang === 'si' ? 'රියදුරෙක්' : 'Driver'}</span>
                <span style={role === 'host' ? styles.chipActive : styles.chip} onClick={() => setRole('host')}>🔌 {lang === 'si' ? 'මධ්‍යස්ථාන හිමිකරුවෙක්' : 'Station Owner'}</span>
              </div>
            </div>
          )}

          {!isLogin && <div style={styles.inputGroup}><User size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="text" placeholder="Full Name" style={styles.authInput} value={fullName} onChange={e => setFullName(e.target.value)} /></div>}
          <div style={styles.inputGroup}><Mail size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="email" placeholder={t.email} style={styles.authInput} value={email} onChange={e => setEmail(e.target.value)} /></div>
          {!isLogin && <div style={styles.inputGroup}><Phone size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="tel" placeholder={t.phone} style={styles.authInput} value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} /></div>}
          
          {!isLogin && role === 'host' && (
            <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} style={{display:'flex', flexDirection:'column', gap:'16px', marginTop: '8px'}}>
              <div style={{fontSize: '12px', color: 'var(--accent)'}}>Charge Station Details</div>
              <div style={styles.inputGroup}><Sun size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="text" placeholder="Station Name (e.g. Saman's Solar)" style={styles.authInput} value={stationName} onChange={e => setStationName(e.target.value)} /></div>
              <div style={styles.inputGroup}><MapPin size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="text" placeholder="Address" style={styles.authInput} value={address} onChange={e => setAddress(e.target.value)} /></div>
            </motion.div>
          )}

          <div style={styles.inputGroup}><Lock size={18} color="var(--text-muted)" style={styles.inputIcon} /><input type="password" placeholder={t.password} style={styles.authInput} value={password} onChange={e => setPassword(e.target.value)} /></div>
          {isLogin && <button style={styles.forgotPassBtn}>{t.forgotPass}</button>}
          <button className="btn btn-primary" style={{ width: '100%', marginTop: '8px' }} onClick={handleAuth}>{isLogin ? t.login : t.register}</button>
          
          {isLogin && (
            <button style={{ background: 'transparent', border: '1px dashed var(--primary)', color: 'var(--primary)', padding: '12px', borderRadius: '16px', marginTop: '16px', fontSize: '13px', cursor: 'pointer' }} onClick={() => { setIsLogin(false); setRole('host'); }}>
              Are you a Charging Center Owner? <span style={{fontWeight: 'bold', textDecoration: 'underline'}}>Register here</span>
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
};


const ExploreScreen = ({ t, onSelectStation, favorites, toggleFav, setActiveTab, stations }) => {
  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [filterType, setFilterType] = useState('All');
  
  return (
    <div style={styles.screenContainer}>
      <div style={styles.header}>
        <div style={styles.searchBar}>
          <Search size={20} color="var(--text-muted)" />
          <input type="text" placeholder={t.searchPlaceholder} style={styles.searchInput} value={search} onChange={(e) => setSearch(e.target.value)} />
          <button style={styles.filterBtn} onClick={() => setShowFilters(true)}><Filter size={20} /></button>
        </div>
      </div>

      {/* NEW: Quick Actions to make it easier for users */}
      <div style={{ display: 'flex', gap: '12px', padding: '0 20px', marginTop: '16px', overflowX: 'auto', scrollbarWidth: 'none' }}>
        <button style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, background: 'var(--surface-light)', border: '1px solid var(--glass-border)', borderRadius: '12px', padding: '12px' }} onClick={() => setActiveTab('charging')}>
          <QrCode size={24} color="var(--primary)" style={{ marginBottom: '8px' }} />
          <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Scan</span>
        </button>
        <button style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, background: 'var(--surface-light)', border: '1px solid var(--glass-border)', borderRadius: '12px', padding: '12px' }} onClick={() => setActiveTab('trip')}>
          <Route size={24} color="var(--accent)" style={{ marginBottom: '8px' }} />
          <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Trip</span>
        </button>
        <button style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, background: 'var(--surface-light)', border: '1px solid var(--glass-border)', borderRadius: '12px', padding: '12px' }} onClick={() => setActiveTab('profile')}>
          <User size={24} color="var(--success)" style={{ marginBottom: '8px' }} />
          <span style={{ fontSize: '12px', fontWeight: 'bold' }}>Profile</span>
        </button>
      </div>

      <div style={{...styles.mapPreview, cursor: 'pointer'}} onClick={() => window.open(`https://www.google.com/maps/search/EV+charging+stations+near+me`, '_blank')}>
        <div style={styles.mapOverlay} />
        <div style={styles.mapMarker} className="animate-pulse"><Zap size={20} color="white" /></div>
        <div style={{ position: 'absolute', bottom: '10px', right: '10px', background: 'var(--surface)', padding: '4px 10px', borderRadius: '8px', fontSize: '10px', color: 'var(--primary)', border: '1px solid var(--primary)' }}>Click to open Live Map</div>
      </div>

      <div style={styles.contentPadding}>
        <div style={styles.sectionHeader}>
          <h2>{t.nearby}</h2>
          <button style={styles.textBtn}>{t.seeAll}</button>
        </div>
        <div className="grid-desktop">
          {stations.filter(s => {
            const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.address.toLowerCase().includes(search.toLowerCase());
            const matchesFilter = filterType === 'All' || (filterType === 'Solar' && s.type === 'home_solar') || (filterType === 'Commercial' && s.type === 'commercial');
            return matchesSearch && matchesFilter;
          }).map(station => (
            <StationCard key={station.id} station={station} onClick={() => onSelectStation(station)} t={t} isFavorite={favorites.includes(station.id)} toggleFav={toggleFav}/>
          ))}
        </div>
      </div>

      <Modal isOpen={showFilters} onClose={() => setShowFilters(false)}>
        <h2>Filters</h2>
        <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <h4>Station Type</h4>
            <div style={styles.filterChips}>
              <span style={filterType === 'All' ? styles.chipActive : styles.chip} onClick={() => setFilterType('All')}>All</span>
              <span style={filterType === 'Commercial' ? styles.chipActive : styles.chip} onClick={() => setFilterType('Commercial')}>Commercial</span>
              <span style={filterType === 'Solar' ? styles.chipActive : styles.chip} onClick={() => setFilterType('Solar')}><Sun size={14} style={{marginRight: '4px', verticalAlign: 'middle'}}/>Solar/Home</span>
            </div>
          </div>
          <button className="btn btn-primary" style={{ marginTop: '20px' }} onClick={() => setShowFilters(false)}>Apply Filters</button>
        </div>
      </Modal>
    </div>
  );
};



const StationDetailScreen = ({ station, onBack, t, onReserve, onStartCharge, isFavorite, toggleFav }) => {
  const [showReport, setShowReport] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);

  return (
    <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25 }} style={styles.detailOverlay}>
      <div style={styles.detailHeader}>
        <button onClick={onBack} style={styles.iconCircleBtn}><ArrowLeft size={24} /></button>
        <button onClick={() => toggleFav(station.id)} style={styles.iconCircleBtn}>
          <Heart size={24} fill={isFavorite ? "var(--error)" : "none"} color={isFavorite ? "var(--error)" : "white"} />
        </button>
      </div>

      <img src={station.image} alt={station.name} style={styles.detailHeroImage} />

      <div style={styles.detailContent}>
        <div style={styles.detailTitleRow}>
          <h1>
            {station.type === 'home_solar' && <Sun size={24} color="#eab308" style={{marginRight: '8px', verticalAlign: 'bottom'}} />}
            {station.name}
          </h1>
          <div style={{...styles.statusBadge, position: 'static', backgroundColor: station.status === 'available' ? 'var(--success)' : 'var(--error)'}}>
            {station.status === 'available' ? t.available : t.occupied}
          </div>
        </div>
        <p style={styles.detailAddress}>{station.address} • {station.hours}</p>

        <div style={{ padding: '12px', background: 'rgba(57, 255, 20, 0.1)', border: '1px solid var(--accent)', borderRadius: '8px', marginBottom: '20px', display: 'flex', gap: '12px', alignItems: 'center' }}>
          <Zap size={24} color="var(--accent)" />
          <p style={{ color: 'var(--accent)', fontSize: '12px', margin: 0 }}><b>{t.smartSuggest}:</b> {t.suggestText}</p>
        </div>

        <div style={styles.detailStats}>
          <div style={styles.detailStatItem}><Zap size={20} color="var(--primary)" /><div><span style={styles.detailStatValue}>{station.power}</span><span style={styles.detailStatLabel}>{t.power}</span></div></div>
          <div style={styles.detailStatItem}><TrendingUp size={20} color="var(--accent)" /><div><span style={styles.detailStatValue}>Rs.{station.price}</span><span style={styles.detailStatLabel}>{t.rate}</span></div></div>
          <div style={styles.detailStatItem}><Star size={20} color="gold" /><div><span style={styles.detailStatValue}>{station.rating}</span><span style={styles.detailStatLabel}>{t.rating}</span></div></div>
        </div>

        <div style={styles.detailSection}>
          <h3>{t.plugs}</h3>
          <div style={styles.plugList}>{station.plugs.map(p => <div key={p} style={styles.plugTag}><Battery size={16}/>{p}</div>)}</div>
        </div>

        <div style={styles.detailSection}>
          <h3>{t.amenities}</h3>
          <div style={styles.amenityList}>{station.amenities.map(a => <div key={a} style={styles.amenityItem}>{a === 'Cafe' ? <Coffee size={18}/> : a === 'Wifi' ? <Wifi size={18}/> : <User size={18}/>}<span>{a}</span></div>)}</div>
        </div>

        <div style={styles.detailSection}>
          <h3>{t.about}</h3>
          <p>{station.description}</p>
        </div>

        {/* NEW: Reviews & Community Section */}
        <div style={styles.detailSection}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <h3>{t.reviews}</h3>
            <button style={{...styles.textBtn, fontSize:'12px'}} onClick={() => setShowReviewModal(true)}><MessageSquare size={14} style={{marginRight:'4px'}}/> {t.writeReview}</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {station.reviewsList && station.reviewsList.length > 0 ? station.reviewsList.map((r, i) => (
              <div key={i} style={{ background: 'var(--surface-light)', padding: '12px', borderRadius: '12px', border: '1px solid var(--glass-border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 'bold', fontSize: '14px' }}>{r.user}</span>
                  <div style={styles.ratingBadge}><Star size={12} fill="gold" color="gold" /><span>{r.rating}</span></div>
                </div>
                <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.8)', margin:0 }}>{r.text}</p>
              </div>
            )) : <p style={{ fontSize: '12px', color: 'var(--text-muted)' }}>No reviews yet. Be the first!</p>}
          </div>
          
          <button style={{...styles.textBtn, marginTop: '16px', color: 'var(--error)', display: 'flex', alignItems: 'center', gap: '8px'}} onClick={() => setShowReport(true)}>
            <AlertTriangle size={16} /> {t.reportIssue}
          </button>
        </div>

        <div style={{...styles.detailActions, flexDirection: 'column'}}>
          <div style={{display: 'flex', gap: '12px', width: '100%'}}>
            <button className="btn" style={{ flex: 1, backgroundColor: 'var(--surface-light)', color: 'white', display: 'flex', gap: '8px', justifyContent: 'center' }} onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(station.name + ' ' + station.address)}`, '_blank')}><Navigation size={20} /> Map</button>
            <button className="btn" style={{ flex: 1, backgroundColor: '#25D366', color: 'white', display: 'flex', gap: '8px', justifyContent: 'center' }} onClick={() => window.open(`https://wa.me/94712345678?text=Hello,%20I%20am%20interested%20in%20charging%20my%20EV%20at%20${encodeURIComponent(station.name)}`, '_blank')}><MessageSquare size={20} /> WhatsApp</button>
          </div>
          <div style={{display: 'flex', gap: '12px', width: '100%', marginTop: '12px'}}>
            <button className="btn btn-primary" style={{ flex: 1, background: 'transparent', border: '1px solid var(--primary)', color: 'var(--primary)', display: 'flex', gap: '8px', justifyContent: 'center' }} onClick={onReserve}>
              <Clock size={20} />{t.schedule}
            </button>
            <button className="btn btn-primary" style={{ flex: 1, background: 'var(--accent)', color: 'black', display: 'flex', gap: '8px', justifyContent: 'center' }} onClick={onStartCharge}>
              <Zap size={20} />Charge
            </button>
          </div>
        </div>
      </div>

      <Modal isOpen={showReport} onClose={() => setShowReport(false)}>
        <h2>{t.reportIssue}</h2>
        <textarea style={{ width: '100%', height: '100px', background: 'var(--surface)', color: 'white', border: '1px solid var(--glass-border)', borderRadius: '8px', padding: '12px', marginTop: '16px' }} placeholder="Describe the issue... (e.g., ICED, Broken plug)" />
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px', background: 'var(--error)' }} onClick={() => { setShowReport(false); alert("Thank you! Your report has been submitted for review."); }}>Submit Report</button>
      </Modal>

      <Modal isOpen={showReviewModal} onClose={() => setShowReviewModal(false)}>
        <h2>{t.writeReview}</h2>
        <div style={{marginTop: '16px'}}>
          <p style={{fontSize:'12px', marginBottom:'8px'}}>Rating:</p>
          <div style={{display:'flex', gap:'8px', marginBottom:'16px'}}>
            {[1,2,3,4,5].map(r => (
              <Star key={r} size={24} fill={r <= reviewRating ? "gold" : "none"} color="gold" onClick={() => setReviewRating(r)} style={{cursor:'pointer'}}/>
            ))}
          </div>
          <textarea style={{ width: '100%', height: '100px', background: 'var(--surface)', color: 'white', border: '1px solid var(--glass-border)', borderRadius: '8px', padding: '12px' }} value={reviewText} onChange={e => setReviewText(e.target.value)} placeholder="Share your experience..." />
        </div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => { setShowReviewModal(false); alert("Review posted successfully!"); setReviewText(""); }}>Post Review</button>
      </Modal>
    </motion.div>
  );
};

const ChargingScreen = ({ t }) => {
  const [isDetecting, setIsDetecting] = useState(true); // FEATURE 4: Plug & Charge
  const [isCharging, setIsCharging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showReceipt, setShowReceipt] = useState(false);

  useEffect(() => {
    if (isDetecting) {
      const timer = setTimeout(() => setIsDetecting(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [isDetecting]);

  useEffect(() => {
    let interval;
    if (isCharging && progress < 100) {
      interval = setInterval(() => setProgress(p => {
        if(p >= 99) { setIsCharging(false); setShowReceipt(true); return 100; }
        return p + 2;
      }), 1000);
    }
    return () => clearInterval(interval);
  }, [isCharging, progress]);

  return (
    <div style={{...styles.screenContainer, justifyContent: 'center', alignItems: 'center'}}>
      <AnimatePresence mode="wait">
        {isDetecting ? (
          <motion.div key="detecting" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={styles.scanContainer}>
            <div style={{...styles.qrPlaceholder, border: '2px solid var(--primary)'}}>
              <Car size={80} color="var(--primary)" className="animate-pulse" />
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 2, repeat: Infinity, ease: "linear" }} style={{ position: 'absolute', inset: 0, border: '4px solid transparent', borderTopColor: 'var(--primary)', borderRadius: '50%' }} />
            </div>
            <h2>{t.autoDetect}</h2>
            <p style={{color: 'var(--text-muted)'}}>{t.plugCharge} Active</p>
          </motion.div>
        ) : !isCharging && !showReceipt ? (
          <motion.div key="scan" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} style={styles.scanContainer}>
            <div style={{...styles.qrPlaceholder, background: 'rgba(0, 242, 255, 0.05)', borderColor: 'var(--primary)'}}>
              <CheckCircle size={40} color="var(--success)" style={{position: 'absolute', top: 10, right: 10}}/>
              <QrCode size={120} color="var(--primary)" />
              <motion.div animate={{ y: [0, 150, 0] }} transition={{ duration: 2, repeat: Infinity }} style={styles.qrScannerLine} />
            </div>
            <h2 style={{color: 'var(--success)'}}>{t.vehicleIdentified}</h2>
            <p style={{color: 'var(--text-muted)', fontSize: '14px'}}>Tesla Model 3 • CCS</p>
            <button className="btn btn-primary" style={{ width: '100%', marginTop: '32px' }} onClick={() => setIsCharging(true)}>{t.startCharge}</button>
          </motion.div>
        ) : isCharging ? (
          <motion.div key="charging" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} style={styles.activeChargingContainer}>
            <div style={styles.chargingCircle}>
              <svg width="240" height="240">
                <circle cx="120" cy="120" r="100" stroke="var(--surface-light)" strokeWidth="12" fill="transparent" />
                <motion.circle cx="120" cy="120" r="100" stroke="var(--primary)" strokeWidth="12" fill="transparent" strokeDasharray="628" strokeDashoffset={628 - (628 * progress) / 100} strokeLinecap="round" />
              </svg>
              <div style={styles.chargingText}>
                <span style={styles.chargePercent}>{Math.round(progress)}%</span>
                <span style={styles.chargeStatus}>Charging...</span>
              </div>
            </div>
            <div style={styles.chargingStats}>
              <div style={styles.statItem}><span style={styles.statLabel}>Power</span><span style={styles.statValue}>42.5 kW</span></div><div style={styles.statDivider} />
              <div style={styles.statItem}><span style={styles.statLabel}>Added</span><span style={styles.statValue}>{(progress * 0.4).toFixed(1)} kWh</span></div><div style={styles.statDivider} />
              <div style={styles.statItem}><span style={styles.statLabel}>Cost</span><span style={styles.statValue}>Rs. {(progress * 30).toFixed(0)}</span></div>
            </div>
            <button className="btn" style={{ width: '100%', marginTop: '40px', backgroundColor: 'var(--error)', color: 'white' }} onClick={() => { setIsCharging(false); setShowReceipt(true); }}>{t.stopSession}</button>
          </motion.div>
        ) : (
          <motion.div key="receipt" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={styles.scanContainer}>
            <CheckCircle size={80} color="var(--success)" style={{ marginBottom: '20px' }} />
            <h2 style={{ color: 'var(--success)' }}>{t.paymentSuccess}</h2>
            <p>{t.invoiceReady}</p>
            <div style={{ background: 'var(--surface-light)', padding: '20px', borderRadius: '12px', width: '100%', margin: '20px 0' }}>
              <p>Energy: <b>{(progress * 0.4).toFixed(1)} kWh</b></p>
              <p>Duration: <b>{(progress * 0.45).toFixed(0)} mins</b></p>
              <h3 style={{ marginTop: '12px', color: 'var(--primary)' }}>Total: Rs. {(progress * 30).toFixed(0)}</h3>
              <p style={{ color: 'var(--success)', fontSize: '12px', marginTop: '8px' }}>+ {(progress / 6).toFixed(0)} Green Points Earned!</p>
              <p style={{ color: 'var(--accent)', fontSize: '12px', marginTop: '4px' }}>+ {(progress * 0.012).toFixed(2)}kg CO2 Offset!</p>
            </div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => { setProgress(0); setShowReceipt(false); setIsDetecting(true); }}>Done</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const TripPlannerScreen = ({ t }) => {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [isPlanning, setIsPlanning] = useState(false);
  const [startSuggestions, setStartSuggestions] = useState([]);
  const [endSuggestions, setEndSuggestions] = useState([]);

  const handleStartChange = (val) => {
    setStart(val);
    if (val.length > 1) {
      setStartSuggestions(SRI_LANKA_CITIES.filter(c => c.toLowerCase().includes(val.toLowerCase())));
    } else {
      setStartSuggestions([]);
    }
  };

  const handleEndChange = (val) => {
    setEnd(val);
    if (val.length > 1) {
      setEndSuggestions(SRI_LANKA_CITIES.filter(c => c.toLowerCase().includes(val.toLowerCase())));
    } else {
      setEndSuggestions([]);
    }
  };

  return (
    <div style={styles.screenContainer} className="overflow-y-auto pb-24">
      <div style={styles.header}>
        <h2>{t.trip || "Trip Planner"}</h2>
      </div>
      <div style={styles.contentPadding}>
        <div style={{ background: 'var(--surface-light)', padding: '20px', borderRadius: '20px', border: '1px solid var(--glass-border)', position: 'relative' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            
            <div style={{position: 'relative'}}>
              <div style={styles.inputGroup}>
                <MapPin size={18} color="var(--primary)" style={styles.inputIcon} />
                <input type="text" placeholder="Start Location" style={styles.authInput} value={start} onChange={e => handleStartChange(e.target.value)} />
              </div>
              {startSuggestions.length > 0 && (
                <div style={styles.suggestionsBox}>
                  {startSuggestions.map(city => (
                    <div key={city} style={styles.suggestionItem} onClick={() => { setStart(city); setStartSuggestions([]); }}>{city}</div>
                  ))}
                </div>
              )}
            </div>

            <div style={{position: 'relative'}}>
              <div style={styles.inputGroup}>
                <Navigation size={18} color="var(--accent)" style={styles.inputIcon} />
                <input type="text" placeholder="Destination" style={styles.authInput} value={end} onChange={e => handleEndChange(e.target.value)} />
              </div>
              {endSuggestions.length > 0 && (
                <div style={styles.suggestionsBox}>
                  {endSuggestions.map(city => (
                    <div key={city} style={styles.suggestionItem} onClick={() => { setEnd(city); setEndSuggestions([]); }}>{city}</div>
                  ))}
                </div>
              )}
            </div>

            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => setIsPlanning(true)}>
              {isPlanning ? "Updating Route..." : "Plan My Trip"}
            </button>
          </div>
        </div>

        {isPlanning && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} style={{ marginTop: '24px' }}>
            <button className="btn" style={{ width: '100%', background: 'linear-gradient(90deg, #4285F4, #34A853)', color: 'white', marginBottom: '20px', display: 'flex', gap: '8px', justifyContent: 'center' }} onClick={() => window.open(`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(start)}&destination=${encodeURIComponent(end)}&travelmode=driving`, '_blank')}>
              <Navigation size={20} /> View Full Route on Google Maps
            </button>
            <div style={styles.sectionHeader}><h3>Recommended Charging Stops</h3></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <div style={{ background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid var(--primary)', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <p style={{ fontWeight: 'bold', margin: 0 }}>Kandy Fast Charger</p>
                  <p style={{ fontSize: '10px', color: 'var(--text-muted)', margin: 0 }}>Stop after 115km • 20 min charge</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ color: 'var(--success)', fontWeight: 'bold', margin: 0 }}>12% → 85%</p>
                </div>
              </div>
              <div style={{ padding: '0 20px' }}><div style={{ width: '2px', height: '20px', background: 'var(--glass-border)', margin: '0 auto' }} /></div>
              <div style={{ background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid var(--glass-border)', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <p style={{ fontWeight: 'bold', margin: 0 }}>Dambulla Solar Hub</p>
                  <p style={{ fontSize: '10px', color: 'var(--text-muted)', margin: 0 }}>Final stop before destination</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ color: 'var(--accent)', fontWeight: 'bold', margin: 0 }}>35% → 90%</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
const CommunityScreen = ({ t, community }) => {
  const [showPostModal, setShowPostModal] = useState(false);
  const [postTitle, setPostTitle] = useState("");
  const [postContent, setPostContent] = useState("");

  return (
    <div style={styles.screenContainer} className="overflow-y-auto pb-24">
      <div style={styles.header}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <h2>{t.community}</h2>
          <button className="btn" onClick={() => setShowPostModal(true)} style={{padding:'8px 16px', fontSize:'12px', background:'var(--primary)', color:'black'}}><Plus size={16}/> {t.postStory}</button>
        </div>
      </div>
    <div style={styles.contentPadding}>
      <div style={{display:'flex', gap:'12px', overflowX:'auto', paddingBottom:'16px', scrollbarWidth:'none'}}>
        {['#Travel', '#Solar', '#Tech', '#Maintenance', '#RoadTrip'].map(tag => (
          <span key={tag} style={styles.chip}>{tag}</span>
        ))}
      </div>
      <div style={{display:'flex', flexDirection:'column', gap:'20px', marginTop:'10px'}}>
        {community.map(story => (
          <motion.div whileHover={{y:-5}} key={story.id} style={{background:'var(--surface-light)', borderRadius:'20px', overflow:'hidden', border:'1px solid var(--glass-border)'}}>
            <img src={story.image} style={{width:'100%', height:'180px', objectFit:'cover'}} alt={story.title}/>
            <div style={{padding:'16px'}}>
              <div style={{display:'flex', alignItems:'center', gap:'8px', marginBottom:'12px'}}>
                <div style={{width:'32px', height:'32px', borderRadius:'16px', background:'var(--primary)', display:'flex', alignItems:'center', justifyContent:'center'}}><User size={16} color="black"/></div>
                <span style={{fontWeight:'bold', fontSize:'14px'}}>{story.user}</span>
              </div>
              <h3 style={{fontSize:'18px', marginBottom:'8px'}}>{story.title}</h3>
              <p style={{fontSize:'13px', color:'var(--text-muted)', lineHeight:'1.5'}}>{story.content}</p>
              <div style={{display:'flex', gap:'16px', marginTop:'16px', borderTop:'1px solid var(--glass-border)', paddingTop:'12px'}}>
                <div style={{display:'flex', alignItems:'center', gap:'4px', color:'var(--error)'}}><Heart size={16} fill="var(--error)"/> <span style={{fontSize:'12px'}}>{story.likes}</span></div>
                <div style={{display:'flex', alignItems:'center', gap:'4px', color:'var(--text-muted)'}}><MessageSquare size={16}/> <span style={{fontSize:'12px'}}>{story.comments}</span></div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>

      <Modal isOpen={showPostModal} onClose={() => setShowPostModal(false)}>
        <h2>{t.postStory}</h2>
        <div style={{marginTop: '16px', display:'flex', flexDirection:'column', gap:'16px'}}>
          <input type="text" placeholder="Title of your story" style={styles.authInput} value={postTitle} onChange={e => setPostTitle(e.target.value)} />
          <textarea style={{ width: '100%', height: '120px', background: 'var(--surface)', color: 'white', border: '1px solid var(--glass-border)', borderRadius: '16px', padding: '16px' }} placeholder="Write your experience..." value={postContent} onChange={e => setPostContent(e.target.value)} />
          <div style={{...styles.qrPlaceholder, height:'100px', border:'1px dashed var(--primary)'}}>
            <Plus size={24} color="var(--primary)"/>
            <p style={{fontSize:'12px', color:'var(--primary)', margin:0}}>Add Photo</p>
          </div>
        </div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => { setShowPostModal(false); alert("Story posted to community!"); setPostTitle(""); setPostContent(""); }}>Post Now</button>
      </Modal>
    </div>
  );
};

const ProfileScreen = ({ t, onSwitchToAdmin, lang, setLang, onLogout, myBookings, profilePic, onProfilePicChange, user, vehicles, onAddVehicle, onDeleteVehicle, onDeleteAccount, onSwitchToSuperAdmin, isSuperAdminEligible, isAdmin }) => {
  const [selectedVehicleId, setSelectedVehicleId] = useState(vehicles && vehicles[0] ? vehicles[0].id : null);
  const activeVehicle = (vehicles || []).find(v => v.id === selectedVehicleId) || (vehicles && vehicles[0] ? vehicles[0] : null);
  const fileInputRef = React.useRef(null);
  const [showAddVehicle, setShowAddVehicle] = useState(false);
  const [showCardModal, setShowCardModal] = useState(false);
  const [newVehicleName, setNewVehicleName] = useState("");
  const [newVehicleBattery, setNewVehicleBattery] = useState("");
  const [newVehicleType, setNewVehicleType] = useState("Car");
  const [newVehicleImage, setNewVehicleImage] = useState(null);
  const [showRegModal, setShowRegModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const handleAvatarClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onProfilePicChange(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  const handleVehicleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewVehicleImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div style={styles.screenContainer} className="overflow-y-auto pb-24">
      <div style={styles.profileHeader}>
        <div style={styles.avatarContainer} onClick={handleAvatarClick}>
          <div style={{...styles.avatar, overflow: 'hidden', cursor: 'pointer', position: 'relative'}}>
            {profilePic ? (
              <img src={profilePic} style={{width:'100%', height:'100%', objectFit:'cover'}} alt="Profile" />
            ) : (
              <User size={40} color="var(--primary)" />
            )}
            <div style={{position: 'absolute', bottom: 0, width: '100%', background: 'rgba(0,0,0,0.5)', color: 'white', fontSize: '10px', padding: '2px 0', textAlign: 'center'}}>Edit</div>
          </div>
          <input type="file" ref={fileInputRef} onChange={handleFileChange} style={{display: 'none'}} accept="image/*" />
        </div>
        <h2>{user?.name || (lang === 'si' ? 'පරිශීලක' : 'User')}</h2>
        <p style={{margin: 0, opacity: 0.7}}>{user?.email || 'user@email.com'}</p>
        <p style={{margin: '4px 0 0 0', color: 'var(--primary)', fontWeight: 'bold'}}>{user?.phone || 'No phone added'}</p>
        
        {!isAdmin && user?.role !== 'host' && (
          <div style={{ background: 'var(--primary)', padding: '12px 24px', borderRadius: '24px', marginTop: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <DollarSign size={16} color="black"/> <span style={{ color: 'black', fontWeight: 'bold' }}>{t.wallet}: Rs. 5,000</span>
          </div>
        )}

        {user?.role === 'host' && (
          <div style={{ background: 'var(--accent)', padding: '12px 24px', borderRadius: '24px', marginTop: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <TrendingUp size={16} color="black"/> <span style={{ color: 'black', fontWeight: 'bold' }}>Business Mode Active</span>
          </div>
        )}
      </div>

      {!isAdmin && user?.role !== 'host' && (
        <div style={{ padding: '0 20px', marginBottom: '20px' }}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px'}}>
            <h3>{t.myVehicles}</h3>
            <button style={styles.textBtn} onClick={() => setShowAddVehicle(true)}><Plus size={14}/> {t.addVehicle}</button>
          </div>
          <div style={{display:'flex', gap:'12px', overflowX:'auto', paddingBottom:'8px', scrollbarWidth:'none'}}>
            {vehicles.map(vehicle => (
              <div key={vehicle.id} style={{ position: 'relative' }}>
                <div onClick={() => setSelectedVehicleId(vehicle.id)} style={{ 
                  minWidth: '140px', background: 'var(--surface-light)', borderRadius: '16px', padding: '12px', 
                  border: selectedVehicleId === vehicle.id ? '2px solid var(--primary)' : '1px solid var(--glass-border)',
                  cursor: 'pointer', transition: 'all 0.3s'
                }}>
                  <img src={vehicle.image} style={{width:'100%', height:'60px', objectFit:'contain', marginBottom:'8px'}} alt={vehicle.name}/>
                  <p style={{margin:0, fontWeight:'bold', fontSize:'12px'}}>{vehicle.name}</p>
                  <p style={{margin:0, fontSize:'10px', color:'var(--text-muted)'}}>{vehicle.type}</p>
                </div>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    if(window.confirm(lang === 'si' ? 'මෙම වාහනය ඉවත් කිරීමට ඔබට විශ්වාසද?' : 'Are you sure you want to delete this vehicle?')) {
                      onDeleteVehicle(vehicle.id);
                    }
                  }}
                  style={{ position: 'absolute', top: '-8px', right: '-8px', background: 'var(--error)', border: 'none', borderRadius: '50%', width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'white' }}
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* FEATURE 3: Carbon Footprint Tracker */}
      <div style={{ margin: '0 20px 20px', background: 'var(--surface-light)', padding: '20px', borderRadius: '20px', border: '1px solid rgba(57, 255, 20, 0.2)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}><TrendingUp size={20} color="var(--success)"/> {t.carbonSavings}</h3>
            <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}>Lifetime impact since joining</p>
          </div>
          <Award size={32} color="var(--success)"/>
        </div>
        <div style={{ display: 'flex', gap: '20px', marginTop: '20px' }}>
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: 0, color: 'var(--success)' }}>124.5 kg</h2>
            <p style={{ margin: 0, fontSize: '10px' }}>{t.co2Saved}</p>
          </div>
          <div style={{ width: '1px', background: 'var(--glass-border)' }} />
          <div style={{ flex: 1 }}>
            <h2 style={{ margin: 0, color: 'var(--primary)' }}>5.2</h2>
            <p style={{ margin: 0, fontSize: '10px' }}>{t.treesPlanted}</p>
          </div>
        </div>
        {/* Simple Bar for progress */}
        <div style={{ marginTop: '20px', height: '8px', background: 'rgba(255,255,255,0.1)', borderRadius: '4px', overflow: 'hidden' }}>
          <motion.div initial={{ width: 0 }} animate={{ width: '70%' }} transition={{ duration: 1 }} style={{ height: '100%', background: 'linear-gradient(90deg, var(--primary), var(--success))' }} />
        </div>
        <p style={{ fontSize: '10px', textAlign: 'center', marginTop: '8px', color: 'var(--text-muted)' }}>70% towards your next 'Eco Warrior' Badge</p>
      </div>

      <div style={{ background: 'linear-gradient(135deg, rgba(0, 242, 255, 0.1), transparent)', border: '1px solid var(--primary)', padding: '20px', borderRadius: '16px', margin: '20px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'relative', zIndex: 2 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ color: 'white', display: 'flex', alignItems: 'center', gap: '8px', margin: 0 }}><Car size={20} color="var(--primary)"/> {activeVehicle?.name || (lang === 'si' ? 'වාහනයක් නැත' : 'No Vehicle')}</h3>
            <p style={{ color: 'var(--success)', fontSize: '12px', margin: 0, display: 'flex', alignItems: 'center', gap: '4px' }}><Radio size={12}/> {t.connected}</p>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '20px', alignItems: 'flex-end' }}>
            <div>
              <h1 style={{ color: 'white', margin: 0, fontSize: '36px' }}>{activeVehicle?.soc || 0}%</h1>
              <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: 0 }}>{t.range}: {activeVehicle?.range || 'N/A'}</p>
            </div>
            <Battery size={48} color="var(--success)" fill="rgba(57, 255, 20, 0.2)" />
          </div>
        </div>
      </div>

      <div style={{ margin: '0 20px 20px', display: 'flex', gap: '12px' }}>
        <div style={{ flex: 1, background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid rgba(57, 255, 20, 0.3)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Award size={28} color="var(--success)" style={{ marginBottom: '8px' }}/>
          <h3 style={{ margin: 0 }}>1,250</h3>
          <p style={{ fontSize: '10px', color: 'var(--success)' }}>{t.greenPoints}</p>
        </div>
        <div style={{ flex: 1.5, background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid rgba(234, 179, 8, 0.3)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <p style={{ fontSize: '12px', textAlign: 'center', marginBottom: '8px', color: 'white' }}>Unlock free charging or discounts!</p>
          <button className="btn" style={{ background: '#eab308', color: 'black', padding: '6px 12px', fontSize: '12px', fontWeight: 'bold' }}>{t.redeem}</button>
        </div>
      </div>

      {myBookings && myBookings.length > 0 && (
        <div style={{ margin: '0 20px 20px' }}>
          <h3 style={{ marginBottom: '12px' }}>Active Bookings</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {myBookings.map((b, i) => (
              <div key={i} style={{ background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid var(--accent)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 'bold' }}>{b.stationName}</span>
                  <span style={{ color: 'var(--accent)' }}>{b.time}</span>
                </div>
                <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>Date: {b.date}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={styles.contentPadding}>
        {!isAdmin && (
          <div style={styles.statsRow}>
            <div style={styles.profileStat}><span style={styles.statVal}>128</span><span style={styles.statLab}>{t.sessions}</span></div>
            <div style={styles.profileStat}><span style={styles.statVal}>4.2k</span><span style={styles.statLab}>kWh</span></div>
            <div style={styles.profileStat}><span style={styles.statVal}>Rs. 12k</span><span style={styles.statLab}>Saved</span></div>
          </div>
        )}

        {isAdmin && (
          <div style={{...styles.card, background: 'linear-gradient(135deg, var(--primary), var(--secondary))', color: 'black', padding: '20px', borderRadius: '20px', marginBottom: '24px'}}>
            <h4 style={{margin:0}}>System Administrator</h4>
            <p style={{margin:0, fontSize: '12px', opacity: 0.8}}>Total Platform Control Enabled</p>
          </div>
        )}

        <div style={styles.menuGroup}>
          <div style={styles.menuItem}>
            <div style={styles.menuItemLeft}><div style={styles.menuIconBox}><Settings size={18} color="var(--text-muted)" /></div><span>Language</span></div>
            <select value={lang} onChange={(e) => setLang(e.target.value)} style={{ background: 'transparent', color: 'var(--primary)', border: 'none', outline: 'none' }}>
              <option value="en">English</option><option value="si">සිංහල</option>
            </select>
          </div>
          {!isAdmin && <MenuItem icon={CreditCard} label={t.rfid} onClick={() => setShowCardModal(true)} />}
          {!isAdmin && <MenuItem icon={Clock} label={t.history} onClick={() => setShowHistoryModal(true)} />}
          {user?.role !== 'host' && !isAdmin && (
            <MenuItem icon={Plus} label={lang === 'si' ? "මධ්‍යස්ථානයක් ලියාපදිංචි කරන්න" : "Register a Station"} onClick={() => setShowRegModal(true)} />
          )}
          {isSuperAdminEligible && !isAdmin && (
            <MenuItem icon={Shield} label="Super Admin Panel" onClick={onSwitchToSuperAdmin} />
          )}
          <div style={{...styles.menuItem, marginTop: '20px'}} onClick={() => {
            if(window.confirm(lang === 'si' ? 'ඔබේ ගිණුම සදහටම මැකීමට ඔබට විශ්වාසද?' : 'Are you sure you want to PERMANENTLY delete your account?')) {
              onDeleteAccount();
            }
          }}>
            <div style={styles.menuItemLeft}><div style={{...styles.menuIconBox, background: 'rgba(255, 77, 77, 0.1)'}}><Trash2 size={18} color="var(--error)" /></div><span style={{color: 'var(--error)'}}>{lang === 'si' ? 'ගිණුම මකන්න' : 'Delete Account'}</span></div>
          </div>
        </div>
        <button className="btn" style={{ width: '100%', marginTop: '24px', backgroundColor: 'transparent', border: '1px solid var(--error)', color: 'var(--error)' }} onClick={onLogout}>
          {t.logout}
        </button>
      </div>

      <Modal isOpen={showAddVehicle} onClose={() => setShowAddVehicle(false)}>
        <h2>{t.addVehicle}</h2>
        <div style={{marginTop: '16px', display:'flex', flexDirection:'column', gap:'16px'}}>
          <input type="text" placeholder="Vehicle Name (e.g. MG ZS EV)" style={styles.authInput} value={newVehicleName} onChange={e => setNewVehicleName(e.target.value)} />
          <input type="text" placeholder="Battery Capacity (kWh)" style={styles.authInput} value={newVehicleBattery} onChange={e => setNewVehicleBattery(e.target.value)} />
          <div style={{display:'flex', gap:'10px'}}>
            <button className="btn" onClick={() => setNewVehicleType("Car")} style={{flex:1, background: newVehicleType === 'Car' ? 'var(--primary)' : 'var(--surface-light)', color: newVehicleType === 'Car' ? 'black' : 'white'}}>Car</button>
            <button className="btn" onClick={() => setNewVehicleType("Bike")} style={{flex:1, background: newVehicleType === 'Bike' ? 'var(--primary)' : 'var(--surface-light)', color: newVehicleType === 'Bike' ? 'black' : 'white'}}>Bike</button>
          </div>
          
          <div style={{marginTop: '10px'}}>
            <label style={{fontSize: '12px', color: 'var(--text-muted)', marginBottom: '8px', display: 'block'}}>Vehicle Photo (Optional)</label>
            <div style={{...styles.qrPlaceholder, height: '120px', border: '1px dashed var(--glass-border)', cursor: 'pointer'}} onClick={() => document.getElementById('vehicleImageInput').click()}>
              {newVehicleImage ? (
                <img src={newVehicleImage} style={{width:'100%', height:'100%', objectFit:'cover'}} alt="New Vehicle" />
              ) : (
                <div style={{textAlign:'center'}}><Plus size={24} color="var(--primary)"/><p style={{fontSize:'12px', margin:0}}>Upload Photo</p></div>
              )}
            </div>
            <input type="file" id="vehicleImageInput" onChange={handleVehicleImageChange} style={{display:'none'}} accept="image/*" />
          </div>
        </div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => { 
          if(!newVehicleName) return;
          const defaultImg = newVehicleType === 'Car' ? 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&q=80&w=200' : 'https://images.unsplash.com/photo-1558981403-c5f91cbba527?auto=format&fit=crop&q=80&w=200';
          onAddVehicle({ id: Date.now(), name: newVehicleName, type: newVehicleType, battery: newVehicleBattery + ' kWh', range: '---', soc: 100, image: newVehicleImage || defaultImg });
          setShowAddVehicle(false); 
          setNewVehicleName("");
          setNewVehicleBattery("");
          setNewVehicleType("Car");
          setNewVehicleImage(null);
          alert("Vehicle registered successfully!"); 
        }}>Register Vehicle</button>
      </Modal>

      <Modal isOpen={showCardModal} onClose={() => setShowCardModal(false)}>
        <h2>Add Payment Card</h2>
        <div style={{marginTop: '16px', display:'flex', flexDirection:'column', gap:'16px'}}>
          <div style={styles.inputGroup}>
            <CreditCard size={18} color="var(--text-muted)" style={styles.inputIcon} />
            <input type="text" placeholder="Card Number (0000 0000 0000 0000)" style={styles.authInput} />
          </div>
          <div style={{display:'flex', gap:'10px'}}>
            <input type="text" placeholder="MM/YY" style={{...styles.authInput, flex: 1}} />
            <input type="text" placeholder="CVC" style={{...styles.authInput, flex: 1}} />
          </div>
          <input type="text" placeholder="Cardholder Name" style={styles.authInput} />
        </div>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => { 
          setShowCardModal(false); 
          alert("Card added successfully!"); 
        }}>{lang === 'si' ? 'කාඩ්පත එක් කරන්න' : 'Add Card'}</button>
      </Modal>
      <Modal isOpen={showRegModal} onClose={() => setShowRegModal(false)}>
        <h2>{t.registerStation}</h2>
        <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={styles.inputGroup}><input type="text" placeholder="Station Name" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <div style={styles.inputGroup}><input type="text" placeholder="Address" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <div style={styles.inputGroup}><input type="number" placeholder="Price per kWh (Rs)" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <button className="btn btn-primary" style={{ marginTop: '16px' }} onClick={() => { setShowRegModal(false); alert("Request submitted for approval!"); }}>Submit Request</button>
        </div>
      </Modal>

      <Modal isOpen={showHistoryModal} onClose={() => setShowHistoryModal(false)}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: '20px'}}>
          <h2 style={{margin:0}}>{t.history}</h2>
          <div style={{background:'var(--primary)', color:'black', padding:'4px 12px', borderRadius:'12px', fontSize:'12px', fontWeight:'bold'}}>128 {t.sessions}</div>
        </div>
        <div style={{maxHeight: '400px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px'}} className="no-scrollbar">
          {[
            { id: 1, station: "Colombo Central Power", date: "Today, 10:30 AM", energy: "45 kWh", cost: "Rs. 3,825" },
            { id: 2, station: "Kandy Express Hub", date: "Yesterday, 4:15 PM", energy: "32 kWh", cost: "Rs. 2,080" },
            { id: 3, station: "Saman's Solar Home", date: "28 Oct, 9:00 AM", energy: "12 kWh", cost: "Rs. 540" },
            { id: 4, station: "Galle Fort Charging", date: "25 Oct, 2:30 PM", energy: "25 kWh", cost: "Rs. 1,875" },
            { id: 5, station: "Colombo Central Power", date: "22 Oct, 11:15 AM", energy: "50 kWh", cost: "Rs. 4,250" }
          ].map(session => (
            <div key={session.id} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', border:'1px solid var(--glass-border)'}}>
              <div style={{display:'flex', justifyContent:'space-between', marginBottom:'8px'}}>
                <span style={{fontWeight:'bold', fontSize:'14px'}}>{session.station}</span>
                <span style={{color:'var(--primary)', fontWeight:'bold'}}>{session.cost}</span>
              </div>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'12px', color:'var(--text-muted)'}}>
                <span>{session.date}</span>
                <span>{session.energy}</span>
              </div>
            </div>
          ))}
        </div>
        <button className="btn" style={{ width: '100%', marginTop: '20px', background: 'rgba(255,255,255,0.05)', color: 'white' }} onClick={() => setShowHistoryModal(false)}>Close</button>
      </Modal>
    </div>
  );
};

const AdminDashboard = ({ t, onBack, myBookings }) => {
  const [showRegModal, setShowRegModal] = useState(false);
  const [regType, setRegType] = useState('commercial');

  return (
    <div style={styles.screenContainer} className="overflow-y-auto pb-24">
      <div style={{...styles.header, display: 'flex', alignItems: 'center', gap: '16px'}}>
        <button onClick={onBack} style={styles.iconCircleBtn}><ArrowLeft size={24} /></button>
        <h2>{t.ownerDashboard}</h2>
      </div>
      <div style={styles.contentPadding}>
        {/* Business Stats Section */}
        <div style={{...styles.adminStatsRow, flexWrap: 'wrap'}}>
          <div style={styles.adminStatCard}>
            <DollarSign size={20} color="var(--success)" />
            <span style={styles.adminStatVal}>Rs. 1,400</span>
            <span style={styles.adminStatLab}>Today</span>
          </div>
          <div style={styles.adminStatCard}>
            <TrendingUp size={20} color="var(--primary)" />
            <span style={styles.adminStatVal}>Rs. 32,500</span>
            <span style={styles.adminStatLab}>This Month</span>
          </div>
          <div style={styles.adminStatCard}>
            <Zap size={20} color="var(--accent)" />
            <span style={styles.adminStatVal}>420</span>
            <span style={styles.adminStatLab}>Monthly kWh</span>
          </div>
        </div>
        
        {/* Active Bookings Section */}
        <div style={{ marginTop: '28px' }}>
          <div style={styles.sectionHeader}>
            <h3 style={{display: 'flex', alignItems: 'center', gap: '8px'}}><Calendar size={18} color="var(--primary)"/> Driver Reservations</h3>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {myBookings && myBookings.length > 0 ? myBookings.map((b, i) => (
              <div key={i} style={{ background: 'var(--surface-light)', padding: '16px', borderRadius: '16px', border: '1px solid var(--glass-border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontWeight: 'bold', fontSize: '15px' }}>Kamal Perera</span>
                  <div style={{...styles.statusBadge, backgroundColor: 'rgba(0, 242, 255, 0.1)', color: 'var(--primary)', position: 'static', padding: '4px 12px'}}>{b.time}</div>
                </div>
                <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: '4px 0' }}>🚗 MG ZS EV (Battery: 20%)</p>
                <p style={{ fontSize: '12px', color: 'var(--primary)', margin: 0, fontWeight: 'bold' }}>Est. Revenue: Rs. 850</p>
              </div>
            )) : (
              <div style={{ background: 'var(--surface-light)', padding: '24px', borderRadius: '16px', textAlign: 'center', color: 'var(--text-muted)', border: '1px dashed var(--glass-border)' }}>
                <Clock size={24} style={{marginBottom: '8px', opacity: 0.5}}/>
                <p style={{margin: 0}}>No active bookings for today.</p>
              </div>
            )}
          </div>
        </div>

        {/* Community & Updates */}
        <div style={{ marginTop: '28px', background: 'linear-gradient(135deg, rgba(0, 242, 255, 0.05), transparent)', padding: '20px', borderRadius: '20px', border: '1px solid var(--glass-border)' }}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px'}}>
            <h3 style={{margin: 0, fontSize: '16px'}}><MessageSquare size={18} color="var(--primary)" style={{marginRight: '8px'}}/> Community Feedback</h3>
            <button style={styles.textBtn} onClick={() => alert("Redirecting to Community...")}>View All</button>
          </div>
          <p style={{fontSize: '13px', color: 'var(--text-muted)', lineHeight: '1.5'}}>
            "Saman's station is very efficient. The solar discount is a great help for daytime charging!"
          </p>
          <p style={{fontSize: '11px', color: 'var(--primary)', marginTop: '8px'}}>— Nuwan (2 hours ago)</p>
        </div>

        {/* Station Control */}
        <div style={{ marginTop: '28px' }}>
          <div style={styles.sectionHeader}>
            <h3>Station Controls</h3>
          </div>
          
          <div style={{...styles.card, border: '1px solid var(--glass-border)', background: 'var(--surface-light)'}}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
              <div>
                <h4 style={{display: 'flex', alignItems: 'center', gap: '6px', margin: 0}}><Sun size={14} color="var(--accent)"/> Saman's Solar Home</h4>
                <p style={{fontSize: '12px', margin: '4px 0'}}>Status: <span style={{color: 'var(--success)'}}>ONLINE</span> • 1 Active Plug</p>
              </div>
              <div style={{ textAlign: 'right' }}><p style={{ color: 'var(--success)', fontWeight: 'bold', margin: 0 }}>Rs. 85</p><p style={{ fontSize: '10px', margin: 0 }}>per kWh</p></div>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button className="btn" style={{ flex: 1, fontSize: '12px', padding: '12px', background: 'rgba(255,255,255,0.05)', border: '1px solid var(--glass-border)', color: 'white' }}>Update Price</button>
              <button className="btn" style={{ flex: 1, fontSize: '12px', padding: '12px', background: 'var(--error)', color: 'white', border: 'none' }}>Go Offline</button>
            </div>
          </div>

          <button className="btn" style={{ width: '100%', marginTop: '16px', background: 'transparent', border: '1px dashed var(--primary)', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }} onClick={() => setShowRegModal(true)}>
            <Plus size={20} /> Register Another Station
          </button>
        </div>
      </div>
      <Modal isOpen={showRegModal} onClose={() => setShowRegModal(false)}>
        <h2>{t.registerStation}</h2>
        <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div style={styles.inputGroup}><input type="text" placeholder="Station Name" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <div style={styles.inputGroup}><input type="text" placeholder="Address" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <div style={styles.inputGroup}><input type="number" placeholder="Price per kWh (Rs)" style={{...styles.authInput, paddingLeft: '16px'}} /></div>
          <button className="btn btn-primary" style={{ marginTop: '16px' }} onClick={() => { setShowRegModal(false); alert("Request submitted!"); }}>Submit for Approval</button>
        </div>
      </Modal>
    </div>
  );
};

const SuperAdminDashboard = ({ t, activeSubTab, stations, setStations, community, setCommunity, user, lang, setLang, profilePic, onProfilePicChange, onLogout }) => {
  const MOCK_USERS = {
    'amila@example.com': { fullName: 'Amila Perera', role: 'driver', phone: '0712345678', location: 'Colombo' },
    'dilini@example.com': { fullName: 'Dilini Silva', role: 'host', phone: '0771234567', location: 'Malabe' },
    'kasun@example.com': { fullName: 'Kasun Jayawardena', role: 'driver', phone: '0751234567', location: 'Jaffna' },
    'nuwan@example.com': { fullName: 'Nuwan Hewage', role: 'driver', phone: '0701234567', location: 'Galle' },
    'piumi@example.com': { fullName: 'Piumi Kanchana', role: 'driver', phone: '0721234567', location: 'Kandy' },
    'sahan@example.com': { fullName: 'Sahan Rajapaksha', role: 'driver', phone: '0761234567', location: 'Negombo' },
    'janaki@example.com': { fullName: 'Janaki Siriwardena', role: 'host', phone: '0741234567', location: 'Kurunegala' },
    'ruwan@example.com': { fullName: 'Ruwan Wickramasinghe', role: 'driver', phone: '0781234567', location: 'Matara' },
    'tharindu@example.com': { fullName: 'Tharindu Mendis', role: 'driver', phone: '0791234567', location: 'Kalutara' },
    'ishani@example.com': { fullName: 'Ishani Fernando', role: 'driver', phone: '0719876543', location: 'Wattala' },
    'malith@example.com': { fullName: 'Malith Gunawardena', role: 'driver', phone: '0779876543', location: 'Gampaha' },
    'chathura@example.com': { fullName: 'Chathura Bandara', role: 'driver', phone: '0759876543', location: 'Anuradhapura' },
    'gayani@example.com': { fullName: 'Gayani Perera', role: 'host', phone: '0709876543', location: 'Batticaloa' },
    'roshan@example.com': { fullName: 'Roshan Abeysekara', role: 'driver', phone: '0729876543', location: 'Trincomalee' },
    'vimukthi@example.com': { fullName: 'Vimukthi Soysa', role: 'driver', phone: '0769876543', location: 'Rathnapura' },
    'priyanka@example.com': { fullName: 'Priyanka Kumari', role: 'host', phone: '0711111111', location: 'Homagama' },
    'suresh@example.com': { fullName: 'Suresh Pathirana', role: 'driver', phone: '0772222222', location: 'Katunayake' },
    'deepika@example.com': { fullName: 'Deepika Ranasinghe', role: 'driver', phone: '0753333333', location: 'Mirissa' },
    'nalin@example.com': { fullName: 'Nalin Karunaratne', role: 'driver', phone: '0704444444', location: 'Colombo 07' },
    'anjali@example.com': { fullName: 'Anjali Mendis', role: 'host', phone: '0725555555', location: 'Hikkaduwa' },
    'pradeep@example.com': { fullName: 'Pradeep Gunawardena', role: 'driver', phone: '0766666666', location: 'Ratnapura' },
    'sewwandi@example.com': { fullName: 'Sewwandi Wickramasinghe', role: 'driver', phone: '0747777777', location: 'Matara' },
    'dinesh@example.com': { fullName: 'Dinesh Liyanage', role: 'host', phone: '0718888888', location: 'Jaffna' },
    'sandun@example.com': { fullName: 'Sandun Herath', role: 'driver', phone: '0779999999', location: 'Kandy' },
    'kavindi@example.com': { fullName: 'Kavindi Fernando', role: 'driver', phone: '0750000000', location: 'Batticaloa' },
    'kamal@example.com': { fullName: 'Kamal Perera', role: 'driver', phone: '0711231234', location: 'Colombo' },
    'nimal@example.com': { fullName: 'Nimal de Silva', role: 'driver', phone: '0773214321', location: 'Kandy' },
    'sunil@example.com': { fullName: 'Sunil Wickrama', role: 'driver', phone: '0755556666', location: 'Galle' },
    'piyal@example.com': { fullName: 'Piyal Munasinghe', role: 'driver', phone: '0707778888', location: 'Malabe' },
    'asanka@example.com': { fullName: 'Asanka Siriwardena', role: 'driver', phone: '0729990000', location: 'Negombo' },
    'indika@example.com': { fullName: 'Indika Jayasooriya', role: 'driver', phone: '0761112222', location: 'Kurunegala' },
    'thushara@example.com': { fullName: 'Thushara Bandara', role: 'driver', phone: '0743334444', location: 'Anuradhapura' },
    'mahesh@example.com': { fullName: 'Mahesh Kumara', role: 'driver', phone: '0715556666', location: 'Matara' },
    'nuwan_p@example.com': { fullName: 'Nuwan Premathilaka', role: 'driver', phone: '0777771111', location: 'Gampaha' },
    'sahan_r@example.com': { fullName: 'Sahan Rathnayake', role: 'driver', phone: '0758889999', location: 'Panadura' }
  };

  const [allUsers, setAllUsers] = useState(() => {
    const saved = JSON.parse(localStorage.getItem('voltcharge_users') || '{}');
    return { ...MOCK_USERS, ...saved };
  });
  
  const normalizedTab = activeSubTab.replace('_admin', '');

  const sosRequests = [
    { id: 1, user: "Amila P.", location: "Kandy Road, Kadawatha", issue: "Battery Dead", time: "10 mins ago", status: "Pending" },
    { id: 2, user: "Nimal D.", location: "Southern Expressway", issue: "Flat Tyre", time: "45 mins ago", status: "Resolved" }
  ];

  const chargingLogs = [
    { id: 1, vehicle: "Tesla Model 3", station: "Colombo Central", energy: "45 kWh", cost: "Rs. 3,825", date: "Today, 10:30 AM" },
    { id: 2, vehicle: "Ather 450X", station: "Kandy Express", energy: "3.2 kWh", cost: "Rs. 210", date: "Today, 11:15 AM" },
    { id: 3, vehicle: "MG ZS EV", station: "Galle Fort Hub", energy: "52 kWh", cost: "Rs. 4,420", date: "Yesterday" },
    { id: 4, vehicle: "Nissan Leaf", station: "Negombo Beach", energy: "22 kWh", cost: "Rs. 1,870", date: "Yesterday" },
    { id: 5, vehicle: "Hyundai Kona", station: "Matara Highway", energy: "60 kWh", cost: "Rs. 5,400", date: "2 days ago" },
    { id: 6, vehicle: "BMW i3", station: "Colombo Central", energy: "30 kWh", cost: "Rs. 2,550", date: "2 days ago" },
    { id: 7, vehicle: "Audi e-tron", station: "Kurunegala Fast", energy: "80 kWh", cost: "Rs. 6,400", date: "3 days ago" },
    { id: 8, vehicle: "Jaguar I-PACE", station: "Jaffna Solar Grid", energy: "70 kWh", cost: "Rs. 5,250", date: "3 days ago" },
    { id: 9, vehicle: "Ola S1 Pro", station: "Kandy Express", energy: "4 kWh", cost: "Rs. 260", date: "4 days ago" },
    { id: 10, vehicle: "BYD Atto 3", station: "Colombo Central", energy: "50 kWh", cost: "Rs. 4,250", date: "4 days ago" }
  ];

  const deleteUser = (email) => {
    if(window.confirm(`Are you sure you want to delete user ${email}?`)) {
      const updated = { ...allUsers };
      delete updated[email];
      setAllUsers(updated);
      localStorage.setItem('voltcharge_users', JSON.stringify(updated));
    }
  };

  const deletePost = (id) => {
    if(window.confirm('Delete this community post?')) {
      setCommunity(community.filter(p => p.id !== id));
    }
  };

  return (
    <div style={styles.screenContainer} className="overflow-y-auto pb-24">
      <div style={{...styles.header}}>
        <h2 style={{fontSize:'24px', color:'var(--primary)', marginBottom: '10px'}}>{normalizedTab.toUpperCase()} MANAGEMENT</h2>
      </div>
      
      <div style={styles.contentPadding}>
        {normalizedTab === 'users' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {Object.keys(allUsers).map(email => (
              <div key={email} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', display:'flex', justifyContent:'space-between', alignItems:'center', border:'1px solid var(--glass-border)'}}>
                <div style={{flex: 1}}>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', marginBottom: '4px'}}>
                    <p style={{margin:0, fontWeight:'bold', fontSize: '15px'}}>{allUsers[email].fullName || 'User'}</p>
                    <span style={{fontSize:'10px', padding:'2px 8px', background: allUsers[email].role === 'host' ? 'var(--accent)' : 'var(--primary)', borderRadius:'10px', color:'black', fontWeight: 'bold'}}>
                      {allUsers[email].role?.toUpperCase()}
                    </span>
                  </div>
                  <p style={{margin:0, fontSize:'12px', color:'var(--text-muted)'}}>{email}</p>
                  <div style={{display: 'flex', gap: '12px', marginTop: '4px'}}>
                    <p style={{margin:0, fontSize:'11px', color:'var(--primary)'}}>📞 {allUsers[email].phone}</p>
                    <p style={{margin:0, fontSize:'11px', color:'var(--text-muted)'}}>📍 {allUsers[email].location}</p>
                  </div>
                </div>
                <button onClick={() => deleteUser(email)} style={{background:'transparent', border:'none', color:'var(--error)', cursor: 'pointer', padding: '8px'}}><Trash2 size={18}/></button>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'vehicles' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {MOCK_VEHICLES_DB.map(v => (
              <div key={v.id} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', display:'flex', justifyContent:'space-between', alignItems:'center', border:'1px solid var(--glass-border)'}}>
                <div>
                  <p style={{margin:0, fontWeight:'bold'}}>{v.name} <span style={{fontSize:'10px', padding:'2px 8px', background:'var(--surface)', borderRadius:'10px', color:'var(--primary)'}}>{v.type}</span></p>
                  <p style={{margin:0, fontSize:'12px', color:'var(--text-muted)'}}>{v.battery} • {v.range} Range</p>
                </div>
                <div style={{textAlign:'right'}}>
                  <span style={{fontSize:'10px', color:'var(--success)'}}>ACTIVE</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'stations' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {stations.map(station => (
              <div key={station.id} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', display:'flex', justifyContent:'space-between', alignItems:'center', border:'1px solid var(--glass-border)'}}>
                <div>
                  <p style={{margin:0, fontWeight:'bold'}}>{station.name}</p>
                  <p style={{margin:0, fontSize:'12px', color:'var(--text-muted)'}}>{station.address} • {station.power}</p>
                </div>
                <button onClick={() => setStations(stations.filter(s => s.id !== station.id))} style={{background:'transparent', border:'none', color:'var(--error)'}}><Trash2 size={18}/></button>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'community' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {community.map(post => (
              <div key={post.id} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', display:'flex', justifyContent:'space-between', alignItems:'center', border:'1px solid var(--glass-border)'}}>
                <div style={{flex:1}}>
                  <p style={{margin:0, fontWeight:'bold', fontSize:'14px'}}>{post.title}</p>
                  <p style={{margin:0, fontSize:'12px', color:'var(--text-muted)'}}>By {post.user}</p>
                </div>
                <button onClick={() => deletePost(post.id)} style={{background:'transparent', border:'none', color:'var(--error)'}}><Trash2 size={18}/></button>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'sos' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {sosRequests.map(req => (
              <div key={req.id} style={{background:'rgba(255, 77, 77, 0.1)', padding:'16px', borderRadius:'16px', border:'1px solid var(--error)'}}>
                <div style={{display:'flex', justifyContent:'space-between', marginBottom:'8px'}}>
                  <span style={{fontWeight:'bold', color:'var(--error)'}}>{req.issue}</span>
                  <span style={{fontSize:'12px', color:'var(--text-muted)'}}>{req.time}</span>
                </div>
                <p style={{margin:'4px 0', fontSize:'14px'}}><b>User:</b> {req.user}</p>
                <p style={{margin:'4px 0', fontSize:'14px'}}><b>Location:</b> {req.location}</p>
                <div style={{marginTop:'12px', display:'flex', gap:'8px'}}>
                  <button className="btn" style={{flex:1, background:'var(--error)', color:'white', fontSize:'12px', padding:'8px'}} onClick={() => alert("Dispatching Help...")}>Dispatch Help</button>
                  <button className="btn" style={{flex:1, background:'var(--surface-light)', fontSize:'12px', padding:'8px'}}>Ignore</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'logs' && (
          <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
            {chargingLogs.map(log => (
              <div key={log.id} style={{background:'var(--surface-light)', padding:'16px', borderRadius:'16px', border:'1px solid var(--glass-border)'}}>
                <div style={{display:'flex', justifyContent:'space-between', marginBottom:'8px'}}>
                  <span style={{fontWeight:'bold'}}>{log.vehicle}</span>
                  <span style={{color:'var(--success)', fontWeight:'bold'}}>{log.cost}</span>
                </div>
                <p style={{margin:0, fontSize:'12px', color:'var(--text-muted)'}}>Station: {log.station} • {log.energy}</p>
                <p style={{margin:'4px 0 0 0', fontSize:'10px', color:'var(--text-muted)'}}>{log.date}</p>
              </div>
            ))}
          </div>
        )}

        {normalizedTab === 'stats' && (
          <div style={{display:'flex', flexDirection:'column', gap:'16px'}}>
            <div style={{background:'linear-gradient(135deg, var(--primary), var(--secondary))', padding:'20px', borderRadius:'20px', color:'black'}}>
              <h3 style={{margin:0}}>Weekly Summary</h3>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'20px', marginTop:'16px'}}>
                <div><p style={{margin:0, fontSize:'12px', opacity:0.8}}>Total Revenue</p><p style={{margin:0, fontSize:'20px', fontWeight:'bold'}}>Rs. 124,500</p></div>
                <div><p style={{margin:0, fontSize:'12px', opacity:0.8}}>Total kWh</p><p style={{margin:0, fontSize:'20px', fontWeight:'bold'}}>1,420 kWh</p></div>
                <div><p style={{margin:0, fontSize:'12px', opacity:0.8}}>Active Users</p><p style={{margin:0, fontSize:'20px', fontWeight:'bold'}}>842</p></div>
                <div><p style={{margin:0, fontSize:'12px', opacity:0.8}}>Carbon Saved</p><p style={{margin:0, fontSize:'20px', fontWeight:'bold'}}>240 kg</p></div>
              </div>
            </div>
            <div style={{background:'var(--surface-light)', padding:'20px', borderRadius:'20px', border:'1px solid var(--glass-border)'}}>
              <h4 style={{margin:'0 0 16px 0'}}>Top Performing Stations</h4>
              <div style={{display:'flex', flexDirection:'column', gap:'12px'}}>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}><span style={{fontSize:'14px'}}>Colombo Central</span><span style={{fontWeight:'bold', color:'var(--primary)'}}>Rs. 42,000</span></div>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}><span style={{fontSize:'14px'}}>Kandy Express</span><span style={{fontWeight:'bold', color:'var(--primary)'}}>Rs. 38,500</span></div>
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}><span style={{fontSize:'14px'}}>Galle Fort Hub</span><span style={{fontWeight:'bold', color:'var(--primary)'}}>Rs. 24,000</span></div>
              </div>
            </div>
          </div>
        )}

        {normalizedTab === 'profile' && (
          <ProfileScreen 
            t={t} user={user} lang={lang} setLang={setLang} 
            profilePic={profilePic} onProfilePicChange={onProfilePicChange}
            onLogout={onLogout} isAdmin={true} vehicles={[]} 
            myBookings={[]} onAddVehicle={() => {}} onDeleteVehicle={() => {}} 
            onDeleteAccount={() => alert("Admin account cannot be deleted.")}
            onSwitchToAdmin={() => {}} onSwitchToSuperAdmin={() => {}}
            isSuperAdminEligible={true}
          />
        )}
      </div>
    </div>
  );
};

const MenuItem = ({ icon: Icon, label, onClick }) => (
  <div style={styles.menuItem} onClick={onClick}>
    <div style={styles.menuItemLeft}><div style={styles.menuIconBox}><Icon size={18} color="var(--text-muted)" /></div><span>{label}</span></div>
    <ChevronRight size={18} color="var(--text-muted)" />
  </div>
);

// --- Main App ---
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null); 
  const [isSuperAdmin, setIsSuperAdmin] = useState(false); // NEW
  const [stations, setStations] = useState(MOCK_STATIONS); // NEW: Manageable stations
  const [community, setCommunity] = useState(MOCK_COMMUNITY); // NEW: Manageable community
  const [vehicles, setVehicles] = useState(MOCK_VEHICLES);
  const [lang, setLang] = useState('en');
  const t = translations[lang];
  
  const [activeTab, setActiveTab] = useState('explore');
  const [selectedStation, setSelectedStation] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [favorites, setFavorites] = useState([]);
  
  const [showReserveModal, setShowReserveModal] = useState(false);
  const [showSOS, setShowSOS] = useState(false);
  const [myBookings, setMyBookings] = useState([]);
  const [selectedTime, setSelectedTime] = useState('09:00 AM');
  const [selectedDate, setSelectedDate] = useState('Today');
  const [profilePic, setProfilePic] = useState(null);

  const handleLogin = (email, userData) => {
    setIsAuthenticated(true);
    const finalUserData = (email === 'admin@gmail.com' && !userData?.name)
      ? { ...userData, name: 'Super Admin', role: 'admin' }
      : userData;
    setUser({ ...finalUserData, email });
    
    // Load user-specific data
    const savedVehicles = JSON.parse(localStorage.getItem(`vehicles_${email}`)) || (email === 'admin@voltcharge.com' ? [] : MOCK_VE_ADMIN_SAFE);
    setVehicles(savedVehicles);
    
    const savedPic = localStorage.getItem(`profile_pic_${email}`);
    setProfilePic(savedPic);
    
    const savedBookings = JSON.parse(localStorage.getItem(`bookings_${email}`)) || [];
    setMyBookings(savedBookings);

    if (email === 'admin@voltcharge.com') {
      setIsSuperAdmin(true);
      setActiveTab('users'); // Default admin tab
    } else if (userData && userData.role === 'host') {
      setIsAdmin(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setActiveTab('explore');
    setSelectedStation(null);
    setIsAdmin(false);
    setIsSuperAdmin(false);
    setVehicles([]);
    setProfilePic(null);
    setMyBookings([]);
  };

  const handleAddVehicle = (newVehicle) => {
    const updated = [...vehicles, newVehicle];
    setVehicles(updated);
    if(user) localStorage.setItem(`vehicles_${user.email}`, JSON.stringify(updated));
  };

  const handleDeleteVehicle = (id) => {
    const updated = vehicles.filter(v => v.id !== id);
    setVehicles(updated);
    if(user) localStorage.setItem(`vehicles_${user.email}`, JSON.stringify(updated));
  };

  const handleDeleteAccount = () => {
    const users = JSON.parse(localStorage.getItem('voltcharge_users') || '{}');
    if (user && user.email) {
      delete users[user.email];
      localStorage.setItem('voltcharge_users', JSON.stringify(users));
      handleLogout();
      alert(lang === 'si' ? 'ඔබේ ගිණුම සාර්ථකව මකා දමන ලදී.' : 'Your account has been deleted successfully.');
    }
  };

  const isSolarDiscountTime = (timeStr) => {
    const ampm = timeStr.slice(-2);
    const hour = parseInt(timeStr.split(':')[0]);
    if (ampm === 'AM' && hour >= 7 && hour !== 12) return true;
    if (ampm === 'PM' && (hour === 12 || hour < 5)) return true;
    return false;
  };

  const toggleFav = (id) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(fid => fid !== id) : [...prev, id]);
  };

  const handleProfilePicChange = (newPic) => {
    setProfilePic(newPic);
    if(user) localStorage.setItem(`profile_pic_${user.email}`, newPic);
  };

  const tabs = [
    { id: 'explore', icon: MapPin, label: t.explore },
    { id: 'trip', icon: Route, label: t.trip },
    { id: 'charging', icon: Zap, label: t.charging },
    { id: 'community', icon: MessageSquare, label: t.community },
    { id: 'profile', icon: User, label: t.profile },
  ];
  
  const hostTabs = [
    { id: 'dashboard_host', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'community', icon: MessageSquare, label: t.community },
    { id: 'profile', icon: User, label: t.profile },
  ];

  const isAdminUser = user?.email === 'admin@gmail.com';
  
  const adminTabs = [
    { id: 'users', icon: User, label: 'Users' },
    { id: 'vehicles_admin', icon: Zap, label: 'Vehicles' },
    { id: 'stations_admin', icon: MapPin, label: 'Stations' },
    { id: 'community_admin', icon: MessageSquare, label: 'Community' },
    { id: 'sos_admin', icon: AlertOctagon, label: 'SOS' },
    { id: 'logs_admin', icon: Clock, label: 'Logs' },
    { id: 'stats_admin', icon: BarChart2, label: 'Stats' },
  ];

  const allTabs = isAdminUser ? adminTabs : (user?.role === 'host' ? hostTabs : tabs);

  if (!isAuthenticated) {
    return (
      <div className="device-wrapper">
        <AuthScreen t={t} onLogin={handleLogin} lang={lang} setLang={setLang} />
      </div>
    );
  }

  return (
    <div className="device-wrapper" style={{ display: 'flex', width: '100vw', height: '100vh', overflow: 'hidden', background: '#0a0b10' }}>
      {/* Desktop Sidebar */}
      <div className="desktop-sidebar">
        <h1 style={{ color: 'var(--primary)', marginBottom: '40px', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <img src="logo.png" alt="Logo" style={{ width: '40px', height: '40px', objectFit: 'contain' }} /> VoltCharge
        </h1>
        {allTabs.map(tab => (
          <button key={tab.id} onClick={() => { 
            setActiveTab(tab.id); 
            setIsAdmin(false); 
            setIsSuperAdmin(isAdminUser);
            setSelectedStation(null); 
          }} style={{...styles.navItem, flexDirection: 'row', justifyContent: 'flex-start', padding: '16px', borderRadius: '12px', background: activeTab === tab.id ? 'var(--surface-light)' : 'transparent', color: activeTab === tab.id ? 'var(--primary)' : 'var(--text-muted)', marginBottom: '8px' }}>
            <tab.icon size={24} /><span style={{ fontSize: '16px', fontWeight: '600' }}>{tab.label}</span>
          </button>
        ))}
        {/* Admin Logout in Sidebar */}
        {isAdminUser && (
          <button onClick={handleLogout} style={{...styles.navItem, flexDirection: 'row', justifyContent: 'flex-start', padding: '16px', borderRadius: '12px', background: 'transparent', color: 'var(--error)', marginTop: 'auto' }}>
            <X size={24} /><span style={{ fontSize: '16px', fontWeight: '600' }}>Logout</span>
          </button>
        )}
      </div>

      <div className="app-container" style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative', height: '100%', overflow: 'hidden' }}>
        <AnimatePresence mode="wait">
          {isAdminUser && activeTab !== 'profile' ? (
            <motion.div key="superadmin" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1, height: '100%' }}>
              <SuperAdminDashboard 
                t={t} activeSubTab={activeTab} onBack={() => setIsSuperAdmin(false)} 
                stations={stations} setStations={setStations} community={community} setCommunity={setCommunity} 
                user={user} lang={lang} setLang={setLang} profilePic={profilePic} 
                onProfilePicChange={handleProfilePicChange} onLogout={handleLogout}
              />
            </motion.div>
          ) : user?.role === 'host' && activeTab === 'dashboard_host' ? (
            <motion.div key="admin" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1, height: '100%' }}>
              <AdminDashboard t={t} onBack={() => {}} myBookings={myBookings} />
            </motion.div>
          ) : isAdmin && activeTab !== 'profile' ? (
            <motion.div key="admin" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} style={{ flex: 1, height: '100%' }}>
              <AdminDashboard t={t} onBack={() => setIsAdmin(false)} myBookings={myBookings} />
            </motion.div>
          ) : (selectedStation && activeTab !== 'profile') ? (
            <StationDetailScreen 
              key="detail" station={selectedStation} t={t} 
              onBack={() => setSelectedStation(null)} 
              isFavorite={favorites.includes(selectedStation.id)} toggleFav={toggleFav}
              onReserve={() => setShowReserveModal(true)}
              onStartCharge={() => { setSelectedStation(null); setActiveTab('charging'); }}
            />
          ) : (
            <motion.div key={activeTab} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflowY: 'auto' }}>
              {activeTab === 'explore' && <ExploreScreen t={t} onSelectStation={setSelectedStation} favorites={favorites} toggleFav={toggleFav} setActiveTab={setActiveTab} stations={stations} />}
              {activeTab === 'trip' && <TripPlannerScreen t={t} />} 
              {activeTab === 'charging' && <ChargingScreen t={t} />}
              {activeTab === 'community' && <CommunityScreen t={t} community={community} />}
              {activeTab === 'profile' && <ProfileScreen t={t} onSwitchToAdmin={() => setIsAdmin(true)} lang={lang} setLang={setLang} onLogout={handleLogout} myBookings={myBookings} profilePic={profilePic} onProfilePicChange={handleProfilePicChange} user={user} vehicles={vehicles} onAddVehicle={handleAddVehicle} onDeleteVehicle={handleDeleteVehicle} onDeleteAccount={handleDeleteAccount} onSwitchToSuperAdmin={() => setIsSuperAdmin(true)} isSuperAdminEligible={user?.email === 'admin@gmail.com'} isAdmin={isAdminUser} />}
              {activeTab === 'favorites' && (
                <div style={styles.screenContainer}>
                  <div style={styles.header}><h2>{t.saved}</h2></div>
                  <div style={styles.contentPadding} className="grid-desktop pb-24">
                    {favorites.length === 0 ? <p>No saved stations.</p> : 
                      stations.filter(s => favorites.includes(s.id)).map(station => (
                        <StationCard key={station.id} station={station} onClick={() => setSelectedStation(station)} t={t} isFavorite={true} toggleFav={toggleFav}/>
                      ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* NEW: Floating SOS Button (Visible in explore and trip tabs) */}
        {(!isAdmin && !selectedStation && (activeTab === 'explore' || activeTab === 'trip')) && (
          <button onClick={() => setShowSOS(true)} style={styles.sosButton}>
            <AlertOctagon size={24} />
          </button>
        )}
      </div>

      {/* Mobile Bottom Nav */}
      {!isAdmin && !selectedStation && (
        <nav className="mobile-bottom-nav" style={styles.bottomNav}>
          {allTabs.map((tab) => (
            <button key={tab.id} onClick={() => {
              if(tab.id === 'superadmin') {
                setIsSuperAdmin(true);
                setIsAdmin(false);
              } else {
                setActiveTab(tab.id);
                setIsSuperAdmin(false);
              }
            }} style={{...styles.navItem, color: (activeTab === tab.id || (tab.id === 'superadmin' && isSuperAdmin)) ? 'var(--primary)' : 'var(--text-muted)' }}>
              <tab.icon size={24} /><span style={styles.navLabel}>{tab.label}</span>
              {(activeTab === tab.id || (tab.id === 'superadmin' && isSuperAdmin)) && <motion.div layoutId="nav-indicator" style={styles.navIndicator} />}
            </button>
          ))}
        </nav>
      )}

      {/* Reservation / Scheduling Modal */}
      <Modal isOpen={showReserveModal} onClose={() => setShowReserveModal(false)}>
        <h2>{t.schedule}</h2>
        
        <p style={{ margin: '16px 0 8px 0', fontSize: '14px', fontWeight: 'bold' }}>Select Date:</p>
        <div style={{...styles.filterChips, marginBottom: '16px'}}>
          {['Today', 'Tomorrow', 'Day After'].map(date => (
            <span key={date} style={selectedDate === date ? styles.chipActive : styles.chip} onClick={() => setSelectedDate(date)}>{date}</span>
          ))}
        </div>

        <p style={{ margin: '0 0 8px 0', fontSize: '14px', fontWeight: 'bold' }}>Select Time:</p>
        <div style={{...styles.filterChips, flexWrap: 'wrap', gap: '8px'}}>
          {['07:00 AM', '09:00 AM', '11:00 AM', '01:00 PM', '03:00 PM', '06:00 PM', '08:00 PM'].map(time => (
            <span key={time} style={selectedTime === time ? styles.chipActive : styles.chip} onClick={() => setSelectedTime(time)}>{time}</span>
          ))}
        </div>
        
        {selectedStation && selectedStation.type === 'home_solar' ? (
          <div style={{ marginTop: '16px', background: 'rgba(255, 200, 0, 0.1)', padding: '12px', borderRadius: '8px', border: '1px solid var(--accent)' }}>
            <p style={{ fontSize: '12px', color: 'var(--accent)', margin: 0 }}>
              ☀️ Solar Special: 20% Discount between 7 AM and 5 PM!
            </p>
            {isSolarDiscountTime(selectedTime) ? (
              <p style={{ fontSize: '14px', color: 'var(--success)', marginTop: '8px', fontWeight: 'bold' }}>Discount Applied! Est. Price: Rs. {(selectedStation.price * 0.8).toFixed(2)} / kWh</p>
            ) : (
              <p style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '8px' }}>Normal rate applies for this time.</p>
            )}
          </div>
        ) : (
          <div style={{ marginTop: '16px', background: 'rgba(57, 255, 20, 0.1)', padding: '12px', borderRadius: '8px', border: '1px solid var(--accent)' }}>
            <p style={{ fontSize: '12px', color: 'var(--accent)', margin: 0 }}>Smart Schedule Tip: Prices drop by 20% after 10:00 PM!</p>
          </div>
        )}
        
        <p style={{ marginTop: '20px', fontSize: '12px' }}>* A reservation fee of Rs. 100 will be deducted from your wallet.</p>
        <button className="btn btn-primary" style={{ width: '100%', marginTop: '16px' }} onClick={() => { 
          setMyBookings([...myBookings, { stationName: selectedStation.name, time: selectedTime, date: selectedDate }]);
          setShowReserveModal(false); 
          alert("Reservation Confirmed! Notification sent."); 
        }}>Confirm Booking</button>
      </Modal>

      {/* NEW: SOS Emergency Modal */}
      <Modal isOpen={showSOS} onClose={() => setShowSOS(false)}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ background: 'rgba(255,0,0,0.1)', width: '80px', height: '80px', borderRadius: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
            <AlertOctagon size={48} color="var(--error)" className="animate-pulse" />
          </div>
          <h2 style={{ color: 'var(--error)' }}>{t.sos}</h2>
          <p style={{ margin: '16px 0' }}>{t.sosDesc}</p>
          <div style={{ background: 'var(--surface-light)', padding: '16px', borderRadius: '12px', marginBottom: '16px', textAlign: 'left', border: '1px solid var(--glass-border)' }}>
            <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>Current Location Detected:</p>
            <p style={{ fontWeight: 'bold', margin: '4px 0 0 0', display: 'flex', alignItems: 'center', gap: '8px' }}><MapPin size={16} color="var(--primary)"/> Colombo, Sri Lanka</p>
          </div>
          <button className="btn" style={{ width: '100%', background: 'var(--error)', color: 'white', fontWeight: 'bold' }} onClick={() => { setShowSOS(false); alert("Help is on the way! A mobile charging van has been dispatched to your location."); }}>{t.requestHelp}</button>
          <button className="btn" style={{ width: '100%', background: 'transparent', color: 'white', marginTop: '12px' }} onClick={() => setShowSOS(false)}>Cancel</button>
        </div>
      </Modal>

    </div>
  );
}

// --- Styles (JSX inline) ---
const styles = {
  screenContainer: { flex: 1, display: 'flex', flexDirection: 'column', width: '100%', height: '100%' },
  header: { padding: '40px 20px 20px 20px', background: 'linear-gradient(to bottom, var(--surface), transparent)', flexShrink: 0 },
  searchBar: { display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--surface-light)', padding: '12px 16px', borderRadius: 'var(--radius-full)', border: '1px solid var(--glass-border)' },
  searchInput: { background: 'transparent', border: 'none', color: 'white', flex: 1, fontSize: '14px', outline: 'none' },
  filterBtn: { background: 'transparent', border: 'none', color: 'var(--primary)', cursor: 'pointer', display: 'flex', alignItems: 'center' },
  mapPreview: { height: '200px', margin: '0 20px 20px 20px', borderRadius: 'var(--radius-lg)', position: 'relative', overflow: 'hidden', border: '1px solid var(--glass-border)', flexShrink: 0 },
  mapOverlay: { position: 'absolute', inset: 0, background: 'url("https://api.mapbox.com/styles/v1/mapbox/dark-v10/static/79.8612,6.9271,12/400x200?access_token=mock") center/cover', opacity: 0.4 },
  mapMarker: { position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: '32px', height: '32px', background: 'var(--primary)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 20px var(--primary)' },
  contentPadding: { padding: '0 20px' },
  sectionHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' },
  textBtn: { background: 'transparent', border: 'none', color: 'var(--primary)', fontSize: '14px', fontWeight: '600', cursor: 'pointer' },
  stationCard: { display: 'flex', flexDirection: 'column', gap: '0', padding: '0', overflow: 'hidden', cursor: 'pointer', marginBottom: '16px' },
  cardImageContainer: { position: 'relative', height: '120px' },
  cardImage: { width: '100%', height: '100%', objectFit: 'cover' },
  statusBadge: { position: 'absolute', top: '12px', right: '12px', padding: '4px 12px', borderRadius: 'var(--radius-full)', fontSize: '10px', fontWeight: '700', textTransform: 'uppercase', color: 'white' },
  favBtnFloating: { position: 'absolute', top: '12px', left: '12px', background: 'rgba(0,0,0,0.5)', border: 'none', width: '30px', height: '30px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
  cardInfo: { padding: '16px' },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' },
  ratingBadge: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', fontWeight: '600' },
  cardAddress: { marginBottom: '12px', fontSize: '12px', color: 'var(--text-muted)' },
  cardFooter: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  plugInfo: { display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px' },
  priceInfo: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px' },
  priceText: { color: 'var(--primary)', fontWeight: '700' },
  dot: { color: 'var(--text-muted)' },
  bottomNav: { height: '80px', background: 'var(--surface)', borderTop: '1px solid var(--glass-border)', justifyContent: 'space-around', alignItems: 'center', padding: '0 10px 10px 10px', position: 'absolute', bottom: 0, width: '100%', zIndex: 5 },
  navItem: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', background: 'transparent', border: 'none', position: 'relative', cursor: 'pointer', flex: 1 },
  navLabel: { fontSize: '10px', fontWeight: '600' },
  navIndicator: { position: 'absolute', top: '-10px', width: '20px', height: '3px', background: 'var(--primary)', borderRadius: '3px', boxShadow: '0 0 10px var(--primary)' },
  scanContainer: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '24px', padding: '20px' },
  qrPlaceholder: { width: '240px', height: '240px', background: 'var(--surface-light)', borderRadius: 'var(--radius-lg)', border: '2px dashed var(--glass-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' },
  qrScannerLine: { position: 'absolute', top: 0, left: 0, width: '100%', height: '2px', background: 'linear-gradient(to right, transparent, var(--primary), transparent)', boxShadow: '0 0 15px var(--primary)' },
  activeChargingContainer: { display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%', padding: '0 32px' },
  chargingCircle: { position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '40px 0' },
  chargingText: { position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center' },
  chargePercent: { fontSize: '48px', fontWeight: '800', color: 'white' },
  chargeStatus: { fontSize: '14px', color: 'var(--primary)', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '2px' },
  chargingStats: { display: 'flex', width: '100%', justifyContent: 'space-between', background: 'var(--surface-light)', padding: '20px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--glass-border)' },
  statItem: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' },
  statLabel: { fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase' },
  statValue: { fontSize: '14px', fontWeight: '700', color: 'white' },
  statDivider: { width: '1px', background: 'var(--glass-border)' },
  profileHeader: { padding: '60px 20px 40px 20px', display: 'flex', flexDirection: 'column', alignItems: 'center', background: 'linear-gradient(to bottom, #1a1c2e, transparent)', flexShrink: 0 },
  avatarContainer: { position: 'relative', marginBottom: '16px' },
  avatar: { width: '100px', height: '100px', borderRadius: '50%', background: 'var(--surface-light)', border: '3px solid var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 20px rgba(0, 242, 255, 0.2)' },
  statsRow: { display: 'flex', justifyContent: 'space-around', marginBottom: '32px' },
  profileStat: { display: 'flex', flexDirection: 'column', alignItems: 'center' },
  statVal: { fontSize: '18px', fontWeight: '700', color: 'white' },
  statLab: { fontSize: '12px', color: 'var(--text-muted)' },
  menuGroup: { background: 'var(--surface-light)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', border: '1px solid var(--glass-border)' },
  menuItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', borderBottom: '1px solid var(--glass-border)', cursor: 'pointer' },
  menuItemLeft: { display: 'flex', alignItems: 'center', gap: '12px' },
  menuIconBox: { width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  detailOverlay: { position: 'absolute', inset: 0, background: 'var(--surface)', zIndex: 20, display: 'flex', flexDirection: 'column', overflowY: 'auto', paddingBottom: '24px' },
  detailHeader: { position: 'absolute', top: '20px', left: 0, right: 0, display: 'flex', justifyContent: 'space-between', padding: '0 20px', zIndex: 21 },
  iconCircleBtn: { width: '44px', height: '44px', borderRadius: '50%', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(10px)', border: '1px solid var(--glass-border)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' },
  detailHeroImage: { width: '100%', height: '300px', objectFit: 'cover', flexShrink: 0 },
  detailContent: { padding: '24px', background: 'var(--surface)', marginTop: '-40px', borderRadius: '40px 40px 0 0', flex: 1 },
  detailTitleRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' },
  detailAddress: { fontSize: '14px', color: 'var(--text-muted)', marginBottom: '24px' },
  detailStats: { display: 'flex', justifyContent: 'space-between', background: 'var(--surface-light)', padding: '16px', borderRadius: 'var(--radius-lg)', marginBottom: '24px' },
  detailStatItem: { display: 'flex', alignItems: 'center', gap: '12px' },
  detailStatValue: { display: 'block', fontSize: '16px', fontWeight: '700' },
  detailStatLabel: { display: 'block', fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase' },
  detailSection: { marginBottom: '24px' },
  plugList: { display: 'flex', gap: '12px', marginTop: '12px', flexWrap: 'wrap' },
  plugTag: { display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', background: 'rgba(0, 242, 255, 0.1)', border: '1px solid var(--primary)', borderRadius: 'var(--radius-full)', fontSize: '14px', fontWeight: '600', color: 'var(--primary)' },
  amenityList: { display: 'flex', gap: '16px', marginTop: '12px' },
  amenityItem: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', fontSize: '12px', color: 'var(--text-muted)' },
  detailActions: { display: 'flex', gap: '12px', marginTop: 'auto', paddingTop: '20px' },
  adminStatsRow: { display: 'flex', gap: '16px', marginTop: '16px' },
  adminStatCard: { flex: 1, background: 'var(--surface-light)', padding: '16px', borderRadius: 'var(--radius-lg)', display: 'flex', flexDirection: 'column', gap: '8px', border: '1px solid var(--glass-border)' },
  adminStatVal: { fontSize: '20px', fontWeight: '800' },
  adminStatLab: { fontSize: '12px', color: 'var(--text-muted)' },
  modalOverlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(5px)', zIndex: 100, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' },
  modalContent: { background: 'var(--surface)', width: '100%', maxWidth: '600px', borderRadius: '24px 24px 0 0', padding: '24px', borderTop: '1px solid var(--glass-border)' },
  modalHandle: { width: '40px', height: '4px', background: 'var(--glass-border)', borderRadius: '2px', margin: '0 auto 20px auto' },
  filterChips: { display: 'flex', gap: '10px', flexWrap: 'wrap' },
  chip: { padding: '8px 16px', border: '1px solid var(--glass-border)', borderRadius: '20px', fontSize: '14px', cursor: 'pointer' },
  chipActive: { padding: '8px 16px', border: '1px solid var(--primary)', background: 'rgba(0, 242, 255, 0.1)', color: 'var(--primary)', borderRadius: '20px', fontSize: '14px', cursor: 'pointer', fontWeight: 'bold' },
  sosButton: { position: 'absolute', bottom: '90px', right: '20px', width: '50px', height: '50px', borderRadius: '25px', background: 'var(--error)', border: 'none', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 4px 20px rgba(255, 77, 77, 0.4)', cursor: 'pointer', zIndex: 10 },
  
  // Auth Styles
  authContainer: { flex: 1, display: 'flex', flexDirection: 'column', background: 'radial-gradient(circle at top right, #1a1c2e, #0a0b10)', minHeight: '100vh' },
  authHero: { padding: '60px 20px 40px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 0.4 },
  authLogoBox: { width: '80px', height: '80px', background: 'linear-gradient(135deg, var(--primary), var(--secondary))', borderRadius: '24px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 10px 30px rgba(0, 242, 255, 0.3)' },
  authFormContainer: { flex: 0.6, background: 'var(--surface)', borderRadius: '40px 40px 0 0', padding: '32px 24px', borderTop: '1px solid var(--glass-border)', display: 'flex', flexDirection: 'column' },
  authTabs: { display: 'flex', borderBottom: '1px solid var(--glass-border)' },
  authTabBtn: { flex: 1, padding: '16px', background: 'transparent', border: 'none', fontSize: '16px', fontWeight: '600', cursor: 'pointer', transition: 'all 0.3s' },
  inputGroup: { position: 'relative', display: 'flex', alignItems: 'center' },
  inputIcon: { position: 'absolute', left: '16px' },
  authInput: { width: '100%', background: 'var(--surface-light)', border: '1px solid var(--glass-border)', borderRadius: '16px', padding: '16px 16px 16px 48px', color: 'white', fontSize: '14px', outline: 'none', transition: 'border-color 0.2s' },
  forgotPassBtn: { alignSelf: 'flex-end', background: 'transparent', border: 'none', color: 'var(--primary)', fontSize: '12px', cursor: 'pointer', marginTop: '-4px' },
  suggestionsBox: { position: 'absolute', top: '100%', left: 0, right: 0, background: 'var(--surface)', border: '1px solid var(--glass-border)', borderRadius: '12px', zIndex: 10, marginTop: '4px', maxHeight: '150px', overflowY: 'auto', boxShadow: '0 10px 25px rgba(0,0,0,0.5)' },
  suggestionItem: { padding: '12px 16px', borderBottom: '1px solid var(--glass-border)', cursor: 'pointer', fontSize: '14px', transition: 'background 0.2s' },
};

export default App;
